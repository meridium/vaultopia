﻿define([
//dojo
    "dojo/dom-class",
    "dojo/_base/array",
    "dojo/_base/connect",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",
    "dojo/NodeList-manipulate",
    "dojo/aspect",
    "dojo/ready",
    "dojo/dnd/Manager",
//dijit
    "dijit/_CssStateMixin",
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/TextBox",
	"dijit/focus",

//epi
    "epi/epi",
    "epi/shell/dnd/Source",
    "epi-cms/widget/_Droppable",
    "epi/dependency",
    "epi-cms/widget/_HasChildDialogMixin",
    "epi/shell/widget/_ValueRequiredMixin",
    "epi-cms/_ContentContextMixin",

//imagevault
    "imagevault/_PropertyMediaMixin",
    "imagevault/_ErrorDisplayMixin",
    "imagevault/RequireModule!ImageVault.EPiServer.UI",
    "epi/i18n!epi/shell/ui/nls/imagevaultepiservercms.propertymedia"
],
function (
//dojo
    domClass,
    array,
    connect,
    declare,
    lang,
    Deferred,
    manipulate,
    aspect,
    ready,
    dndManager,
//dijit
    _CssStateMixin,
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    TextBox,
	focusUtil,

//epi
    epi,
    source,
    _DroppableMixin,
    dependency,
    _HasChildDialogMixin,
    _ValueRequiredMixin,
    _ContentContextMixin,
    
//imagevault
    _PropertyMediaMixin,
    _ErrorDisplayMixin,
    appModule,
    res
) {

	return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _CssStateMixin, _DroppableMixin, _PropertyMediaMixin, _HasChildDialogMixin, _ValueRequiredMixin, _ContentContextMixin], {
        //dropAreaNode (from _Droppable) is selected using the data-dojo-attach-point="dropAreaNode" on the element that should be the target.
        templateString: '\
<div class="dijitInline" >\
    <input type="hidden" data-dojo-attach-point="hiddenField" data-dojo-type="dijit/form/TextBox" />\
    <input type="hidden" data-dojo-attach-point="thumbnailHiddenField" data-dojo-type="dijit/form/TextBox" />\
    <div class="propertymedia-control">\
        <span class="propertymedia-droparea" data-dojo-attach-event="onclick:_openImageVault" data-dojo-attach-point="dropAreaNode">\
            <span class="propertymedia-outer-thumbnail-container">\
                <span class="propertymedia-thumbnail-container" >\
                    <img data-dojo-attach-point="thumbnail" src="" class="propertymedia-thumbnail" />\
                </span>\
            </span>\
        </span>\
        <div class="propertymedia-button-row">\
            <a data-dojo-attach-point="removeLink" data-dojo-attach-event="onclick:_removeImage" class="propertymedia-btn propertymedia-remove propertymedia-btn-disabled"><span>${resources.clearbuttontext}</span></a>\
            <a data-dojo-attach-point="editLink" data-dojo-attach-event="onclick:_editImage" class="propertymedia-btn propertymedia-edit propertymedia-btn-disabled"><span>${resources.editbuttontext}</span></a>\
            <a data-dojo-attach-point="insertLink, focusNode" data-dojo-attach-event="onclick:_openImageVault" class="propertymedia-btn">${resources.insert}</a>\
        </div>\
    </div>\
</div>',
        baseClass: "ivpm",
        thumb: "",
        value: null,
        propertyMediaScript: null,
        width: null,
        height: null,
        resizeMode: null,
        thumbEffect: null,
        thumbFormatId: null,
        thumbCache: { Thumb: { Url: ""} },
        mediaCacheItem: null,
        propertyMedia: null,
		//7.1 only, to be removed...
        acceptDataTypes: ["ImageVaultMedia"],
		//7.5 introduced allowedDndTypes instead of acceptDataTypes
        allowedDndTypes: ["ImageVaultMedia"],
        resources: res,

        postCreate: function () {
            //this handler will be notified when the callback to the PropertyMedia
            // store anrop för att få in "editordescriptor" -grejer
            // ska även stödja block
            this.ErrorNode = this.dropAreaNode;
            this._contextChangedHandler = connect.subscribe('/imagevault/propertymedia', this, this._onContextChange);

            this.thumbnail.id = this.hiddenField.id.replace('TextBox', 'thumbnail');
            this.removeLink.id = this.hiddenField.id.replace('TextBox', 'removeLink');
            this.editLink.id = this.hiddenField.id.replace('TextBox', 'editLink');
            this.insertLink.id = this.hiddenField.id.replace('TextBox', 'insertLink');

            this.hiddenField.set("intermediateChanges", true);
            this.connect(this.hiddenField, "onChange", this._onHiddenFieldChanged);
            this.connect(this.hiddenField, "onBlur", this._onHiddenFieldBlur);

            //Listen to all dnd events
            this.subscribe("/dnd/start", function () { this._feedbackOnDrag(true); });
            this.subscribe("/dnd/cancel", function () { this._feedbackOnDrag(false); });
            this.subscribe("/dnd/drop", function () { this._feedbackOnDrag(false); });

        	//Listen to ImageVault Window events
            this.subscribe("/imagevault/propertymediacommon/ivwinclosed", function (caller) {
            	if (this.propertyMedia === caller) {
		            this._ivWindowClosed();
	            }
            });
            this.subscribe("/imagevault/propertymediacommon/ivwinopened", function (caller) {
            	if (this.propertyMedia === caller) {
		             this._ivWindowOpened();
	            }
            });

            //setup the stores
            try {
                if (!this.store || !this.datastore) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this.store = registry.get("imagevault.mediaitemstore");
                    this.datastore = registry.get("imagevault.mediapropertydatastore");
                }
            } catch(err) {
                this.ShowError("Error initializing stores: " + err);
            }

            //load the scripts from the _PropertyMediaMixin and after that, init the component
            this.loadScripts().then(lang.hitch(this, function () {
                ready(lang.hitch(this, function () {
                	Deferred.when(this.datastore.query({ contextId: this.getCurrentContext().id, propertyName: this.fullName, width: this.width, height: this.height, resizeMode: this.resizeMode, mode: this.getCurrentContext().currentMode }), lang.hitch(this, function (storeResponse) {
                        if (storeResponse.ErrorCode) {
                            // something went wrong
                            this.ShowError("Error in store:" + storeResponse.ErrorMessage);
                            return;
                        }

                        // set all properties before initializing
                        this.thumbFormatId = storeResponse.ThumbFormatId;
                        this.thumbEffect = storeResponse.ThumbEffects;
                        this.thumbCache = storeResponse.ThumbCache;
                        
                        // Set thumbnail
                        if (this.thumbCache) {
                            this.thumbnailHiddenField.set("value", this.thumbCache);
                            this.mediaCacheItem = JSON.parse(this.thumbCache);
                            this.thumb = this.mediaCacheItem.Thumb.Url;
                            this.thumbnail.setAttribute("src", this.thumb);
                        }
                        
                        this.initPropertyMedia();
                	}
                    ));
                }));
            }));

            // call base implementation
            this.inherited(arguments);

            if (this.readOnly)
                this.acceptDataTypes = [];

        },

        initPropertyMedia: function () {
            this.propertyMedia = new ImageVault.PropertyMedia({
                hiddenFieldId: this.hiddenField.id,
                thumbnailHiddenFieldId: this.thumbnailHiddenField.id,
                thumbnailId: this.thumbnail.id,
                removeLinkId: this.removeLink.id,
                editLinkId: this.editLink.id,
                thumbnailFormatId: this.thumbFormatId,
                inserLinkId: this.insertLink.id,
                targetWidth: this.width,
                targetHeight: this.height,
                resizeMode: this.resizeMode,
                propertyThumbnailWidth: this.thumbEffect[0].Width,
                propertyThumbnailHeight: this.thumbEffect[0].Height,
                propertyThumbnailResizeMode: this.thumbEffect[0].ResizeMode,
                clickEvents: false,
                readOnly: this.readOnly
            });

            this.propertyMedia.UpdateUi();
            this.propertyMedia.centerThumbnail($("#" + this.thumbnail.id), this.mediaCacheItem);
        },
        _onContextChange: function (pm) {
            //check if event is for us.
            if (this.propertyMedia !== pm)
                return;
            //Start to listen to focus/blur-events
            this.isShowingChildDialog = false;
            // Widget will update itself using the new context.
            var mediaReference = this.propertyMedia.getHiddenFieldValue();
            if (mediaReference) {
                this._setValue(mediaReference, false);
            }

            // needed for trigger autosave in EPi7
            focusUtil.focus(this.ownerDocumentBody);
        },
        _feedbackOnDrag: function (/*bool*/start) {
            // summary:
            //      gives visual feedback when dragging starts
            // start:
            //      true if drag is starting, false if it is ending

            var isDragItemAcceptable = false;
            if (start) {
                var manager = dndManager.manager();
                //nodes refer to all currently dragged nodes 
                isDragItemAcceptable = array.some(manager.nodes, function (node) {
                    var item = manager.source.getItem(node.id);
                    if (!item)
                        return false;
                    //check if the item has acceptable data types
                    return array.some(item.type, function (type) {
                        return array.some(this.acceptDataTypes, function (acceptType) {
                            return type == acceptType;
                        }, this);
                    }, this);
                }, this);
            }

            if (isDragItemAcceptable) {
                domClass.add(this.dropAreaNode, "dojoDndItemAcceptable");
            } else {
                domClass.remove(this.dropAreaNode, "dojoDndItemAcceptable");
            }
        },
        focus: function () {
        	focusUtil.focus(this.domNode);
            this.inherited(arguments);
        },

        _onDropData: function (dndData/*, source, nodes, copy*/) {
            if (this.readOnly)
                return;
            var dropItem = dndData ? (dndData.length ? dndData[0] : dndData) : null;
            var self = this;
            if (dropItem) {
                this.onDropping();

                Deferred.when(self.store.query({ id: dropItem.data.Id, formatId: self.thumbFormatId }), function (mediaCache) {

                	//update mediaCache in propertyMedia
                    self.propertyMedia.mediaCache = mediaCache;

                    //create mediaReference and store the value
                    var mediaReference = { Id: dropItem.data.Id };

                    //store mediaCache in thumbnailHidden field
                    self.thumbnailHiddenField.set("value", JSON.stringify(mediaCache));

                    self._setValue(mediaReference, true);

                    //update thumbnail
                    self.thumbnail.setAttribute("src", mediaCache.Thumb.Url);
                    self.thumbnail.setAttribute('style', 'visibility:hidden');
                    self.propertyMedia.centerThumbnail($("#" + self.thumbnail.id), mediaCache);
                    //notify the property media that the content has been changed
                    self.propertyMedia.UpdateUi();
                });
            }

        },

        isValid: function () {
            // summary:
            //    Check if widget's value is valid.
            // tags:
        	//    protected, override
	        //
        	// 2014-03-11/RW: Since the value also may be be an empty object,
	        //	make sure to verify this scenario as well.
	        var value = this.value;
			if (typeof(this.value) === "object") {
				value = JSON.stringify(this.value);
			}
            return !this.required || this.value && value != "" && value != "{}";
        },

        // Setter for value property
        _setValueAttr: function (value) {
            this._setValue(value, true);
        },

        _setReadOnlyAttr: function (value) {
            this._set("readOnly", value);
            if (this.propertyMedia)
                this.propertyMedia.readOnly = this.readOnly;
        },

        // Event handler for InsertLink
        _openImageVault: function () {
            if (this.readOnly)
                return;
            this.propertyMedia.OpenImageVault(false);
        },

		// Set this objects state when the window is opened.
        _ivWindowOpened: function () {
        	this.isShowingChildDialog = true;
        },

		// Reset this objects state when the window is closed.
        _ivWindowClosed: function () {
			this.isShowingChildDialog = false;
		},

        // Event handler for InsertLink
        _removeImage: function () {
            if (this.readOnly)
                return;
            var self = this;
            var $removeLink = $('#' + self.removeLink.id);
            if ($removeLink.hasClass('propertymedia-btn-disabled')) {
                return false;
            }

            var doClear = confirm(ImageVault.PropertyMediaCommon.clearConfirmMessage);
            if (doClear) {
                self.isShowingChildDialog = true;
                // update thumbnail
                self.thumbnail.setAttribute("src", ImageVault.PropertyMediaCommon.defaultIconUri);
                self.thumbnail.setAttribute('style', 'visibility:hidden');
                self.propertyMedia.centerThumbnail($("#" + self.thumbnail.id));

                // remove mediaCache from propertymedia
                self.propertyMedia.mediaCache = null;

                // notify the property media that the content has been changed
                self.propertyMedia.UpdateUi();

                // update value for propertymedia
                self.isShowingChildDialog = false;
                self._setValue(null, false);

                // needed for trigger autosave in EPi7
                focusUtil.focus(self.ownerDocumentBody);
	            self.validate();
	            focusUtil.focus(self.domNode);
			}
        },

        // Event handler for InsertLink
        _editImage: function () {
            if (this.readOnly)
                return false;
            if ($("#" + this.editLink.id).hasClass("propertymedia-btn-disabled"))
                return false;
            this.isShowingChildDialog = true;

            this.propertyMedia.mediaCache = JSON.parse(this.thumbnailHiddenField.textbox.value);
            this.propertyMedia.edit();
            return false;
        },

        // Event handler for textarea
        _onHiddenFieldChanged: function (newValue) {
            if (this.readOnly)
                return;

            this._setValue(newValue, false);
        },

        validate: function () {
			return this.inherited(arguments);
        },

        _setValue: function (value, updateFields) {

            var mediaReference = value;
            var mediaReferenceString = value;

            if (value === null || typeof (value) === "undefined" || value === "") {
                mediaReference = null;
                mediaReferenceString = null;

            } else if (typeof (value) === "string") {
                mediaReference = JSON.parse(value);

            } else if (typeof (value) === "object") {
                mediaReferenceString = JSON.stringify(value);
            }
            if (updateFields) {
                this.hiddenField.set("value", mediaReferenceString == null ? "{}" : mediaReferenceString);
            }
            //this.set("value", mediaReference);
            this.value = mediaReference == null ? '' : mediaReference;
            if (mediaReference != null && this.onChange)
				this.onChange(mediaReference);

        	// Reset the state property before validation
            this.set("state", undefined);
        }
    });
});
