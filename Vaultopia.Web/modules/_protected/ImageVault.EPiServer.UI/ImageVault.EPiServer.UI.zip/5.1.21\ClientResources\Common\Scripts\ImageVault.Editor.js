﻿(function ($, ns) {

    var editor = function (config) {
        this.init(config);

        return this;
    };

    // Extends jQuery with a function that returns a css-property as Float
    $.fn.cssVal = function (cssPropertyName) {
        var stringVal = $(this).css(cssPropertyName);
        if (!stringVal || stringVal === "auto")
            return 0;
        return parseFloat(stringVal);
    };

    editor.prototype = {
        //properties

        //The editor wrapper dom object.
        $domobj: null,
        //The outer image object.
        $imageobj: null,
        //Overlay layer. This property is set by the editor at initialization
        $overlay: null,
        //Outline layer. This property is set by the editor at initialization
        $outline: null,
        //Selection layer. This property is set by the editor at initialization
        $selection: null,
        //Selection image layer. This property is set by the editor at initialization
        $selectionImage: null,
        $workspace: null,
        $preloadobj: null,
        //All resize handlers are set by the editor at initialization
        $nwResizeHandler: null,
        $swResizeHandler: null,
        $seResizeHandler: null,
        $neResizeHandler: null,
        $nResizeHandler: null,
        $sResizeHandler: null,
        $wResizeHandler: null,
        $eResizeHandler: null,
        $cropWarningImage: null,
        $reloadEditorButton: null,
        $editorButtonsArea: null,
        $slider: null,
        editorWidth: 1024, //defines the popup window width
        editorHeight: 768, //defines the popup window height
        propertyWidth: null,
        propertyHeight: null,
        cropCoordinates: { top: 100, left: 100, height: 100, width: 100, scale: 1, topFromImage: 0, leftFromImage: 0, unscaledWidth: 100, unscaledHeight: 100 },
		cropAspectRatio: null,
        zoomLevel: 100,
        originalZoomLevel: null,
        step: 10,
        aspectRatio: null,
        originalImageWidth: 1024,  //height on original image even if smaller image version is loaded
        originalImageHeight: 768,  //width on original image even if smaller image version is loaded
        oldImageWidthCtrlValue: null,
        oldImageHeightCtrlValue: null,
        originalUrl: null,
        resizeMode: 0,
        dragImage: false,
        dragHandler: false,
        currentHandle: null,
        mouseX: 0,
        mouseY: 0,
        cropareaBorderWidth: 1,
        workspaceAreaMargin: 20,
        overlayOpacity: 0.75,
        outlineOpacity: 1,
        imageId: null,
        currentEffects: null,
        //the client to use for communicating with core
        client: null,
        //the base url of the media CDN
        mediaUrlBase: null,
        editorWidthInputLabel: "Width",
        editorHeightInputLabel: "Height",
        editorOkButtonText: "OK",
        editorCancelButtonText: "Cancel",
        editorWarningIconText: "Now your picture is showing in a reduced size because the image does not fit in the workspace. When you publish the image size will be correct.",
        editorReloadButtonText: "Reload",
        editorLoadErrorText: "An error occurred while loading the editor.",

        //methods
        init: function (config) {
            $.extend(this, config);

            var self = this;

        	//Initialize Image and Crop DOM
            this.setupDOM();

            //Get width, height and margins from DOM
            this.cropareaBorderWidth = parseInt(this.$outline.css("borderTopWidth").replace("px", ""));
            if (this.cropareaBorderWidth == "")
                this.cropareaBorderWidth = 0;

            this.editorSliderHeight = this.$editorSlider.height() + this.workspaceAreaMargin * 2;
            this.editorActionHeight = this.$editorAction.height() + 15; //margin on editor-actions

            //Resize workspace, image and croparea
            this.aspectRatio = this.originalImageWidth / this.originalImageHeight;
            this.workspaceHeight = this.calculateWorkSpaceHeight() - 2 - this.cropareaBorderWidth * 2;
            this.workspaceWidth = this.editorWidth - 2 - this.cropareaBorderWidth * 2; //full width - margin

            this.setupLanguage();
            this.setupWindowSize();

            try {
                this.updateEffects(this.currentEffects, true);
            } catch (e) {
                alert(this.editorLoadErrorText + "\r\nError message details: " + e);

                this.callback(null);
                window.ownerDocument.close();

                return false;
            }

            registerEvents(this);

            var parameters = {
                Filter: { Id: [this.imageId] },
                Populate: {
                    MediaFormats: [{ $type: "ImageVault.Common.Data.ImageFormat,ImageVault.Common"}]
                },
                MediaUrlBase: this.mediaUrlBase
            };

            //we stringify the parameters first before passing to the client
            //the client resides in the parent window and for IE that means passing arrays over windows makes them to objects (assocciative arrays)
            //thus the json gets all mixed up.
            var json = JSON.stringify(parameters);
            this.client.json("MediaService/Find", json, function (x) {
                if (x == null) {
                    alert("Error calling ImageVault Core. [" + self.client._lastError.message + " (status:" + self.client._lastError.status + ")]");
                    self.callback(null);
                    return;
                }
                var index = 0;
                if (x[0].MediaConversions[index].MediaFormatName != "System")
                    index = 1;

                self.setOriginalImage(x[0].MediaConversions[index].Url);
            });

        },
        setOriginalImage: function (url) {
            this.$imageobj.attr("src", url);
            this.$selectionImage.attr("src", url);

            this.$preloadobj.fadeOut(400);
        },
        callback: function () {
        },

        setupDOM: function () {
            var self = this;

            this.$workspace = $('<div id="editor-workspace" />');
            this.$imageobj = $('<img id="editor-image" alt="Use the controls to alter the image" />');
            this.$workspace.append(this.$imageobj);
            this.$domobj.append(this.$workspace);

            this.$editorSlider = $('<div id="editor-slider" />');
            this.$editorSliderInner = $('<div id="editor-slider-inner" />');
            this.$editorSlider.append(this.$editorSliderInner);

            this.$editorSliderMinValue = $('<div id="editor-slider-min-value">0%</div>');
            this.$slider = $('<div id="editor-slider-bar" class="iv-slider-bar" />').slider({
                range: "min",
                value: 0,
                min: 0,
                max: 100,
                step: 0.2,
                slide: function (event, ui) {
                    return self.zoomImage(null, ui.value);
                }
            });
            this.$editorSliderMaxValue = $('<div id="editor-slider-max-value">100%</div>');
            this.$editorSliderInner.append(this.$editorSliderMinValue);
            this.$editorSliderInner.append(this.$slider);
            this.$editorSliderInner.append(this.$editorSliderMaxValue);

            this.$editorButtonsAreaContainer = $('<div id="editor-buttons-area-container" />');

            this.$editorButtonsArea = $('<div id="editor-buttons-area" />');

            this.$controlArea = $('<div class="control-area" />');

	        this.$divImageWidth = $('<div class="control-area-width"></div>');
            this.$labelImageWidth = $('<label id="label-image-width" for="image-width">Width:</label>');
            this.$inputImageWidth = $('<input id="image-width" type="text" tabindex=1 value="0" />');
            this.$divImageWidth.append(this.$labelImageWidth);
            this.$divImageWidth.append(this.$inputImageWidth);
	        if (this.KeepAspectRatio) {
		        this.$actionKeepAspectRatio = $('<a id="keep-aspect-ratio" class="active" tabindex=0 href="#" title="Constrain proportions"></a>');
	        }
	        this.$divImageHeight = $('<div class="control-area-height"></div>');
	        this.$labelImageHeight = $('<label id="label-image-height" for="image-height">Height:</label>');
            this.$inputImageHeight = $('<input id="image-height" type="text" tabindex=2 value="0" />');
            this.$divImageHeight.append(this.$labelImageHeight);
            this.$divImageHeight.append(this.$inputImageHeight);
            this.$controlArea.append(this.$divImageWidth);
	        if (this.KeepAspectRatio) {
		        this.$controlArea.append(this.$actionKeepAspectRatio);
	        }
	        this.$controlArea.append(this.$divImageHeight);

            this.$editorButtonsArea.append(this.$controlArea);

            this.$editorButtonsArea.append(this.$editorSlider);

            this.$editorAction = $('<div id="editor-actions" />');
            this.$actionSaveEditor = $('<a id="save-editor" href="#" class="propertymedia-btn save-button">OK</a>');
            this.$actionCancelEditor = $('<a id="cancel-editor" href="#" class="propertymedia-btn cancel-button">Cancel</a>');
            this.$editorAction.append(this.$actionSaveEditor);
            this.$editorAction.append(this.$actionCancelEditor);

            this.$editorButtonsArea.append(this.$editorAction);
            this.$editorButtonsAreaContainer.append(this.$editorButtonsArea);
            this.$domobj.append(this.$editorButtonsAreaContainer);

            // Initialize an overlay layer and place it above the image
            this.$overlay = $('<div id="image-crop-overlay" />')
                .css({
                    opacity: this.overlayOpacity,
                    position: 'absolute',
                    display: 'block'
                })
                .insertAfter(this.$imageobj);

            // Initialize an outline layer and place it above the trigger layer
            this.$outline = $('<div id="image-crop-outline" />')
                .css({
                    opacity: this.outlineOpacity,
                    position: 'absolute',
                    display: 'block'
                })
                .insertAfter(this.$overlay);

            // Initialize warning icon
            this.$cropWarningImage = $('<div id="editor-croparea-warning" />');
            this.$outline.append(this.$cropWarningImage);

            // Initialize warning text over icon
            this.$outline.append('<div class="editor-warning-message-popup" style="display: none;"></div>');

            // Initialize Reload button
            this.$reloadEditorButton = $('<a href="#" id="reloadEditor" class="propertymedia-btn reload-button" style="display: none;"><span class="reload-label">Ladda om</span></a>');
            this.$outline.append(this.$reloadEditorButton);

            // Trigger hover function for show and hide warning text
            var timeout;
            this.$cropWarningImage.hover(function () {
                timeout = setTimeout(function () {
                    $(".editor-warning-message-popup").fadeIn(500);
                }, 500);
            }, function () {
                clearTimeout(timeout);
                $(".editor-warning-message-popup").fadeOut(500);
            });

            // Initialize a selection layer and place it above the outline layer
            this.$selection = $('<div />')
                .css({
                    position: 'absolute',
                    overflow: 'hidden'
                })
                .insertAfter(this.$outline); // Initialize a north/west resize handler and place it above the

            this.$selectionImage = $("<img/>").css("position", "absolute");
            this.$selection.append(this.$selectionImage);

            // selection layer
            this.$nwResizeHandler = $('<div class="image-crop-resize-handler" id="image-crop-nw-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize a north/east resize handler and place it above the
            // selection layer
            this.$neResizeHandler = $('<div class="image-crop-resize-handler" id="image-crop-ne-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize a south/west resize handler and place it above the
            // selection layer
            this.$swResizeHandler = $('<div class="image-crop-resize-handler" id="image-crop-sw-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize a south/east resize handler and place it above the
            // selection layer
            this.$seResizeHandler = $('<div class="image-crop-resize-handler" id="image-crop-se-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize a north resize handler and place it above the selection
            // layer
            this.$nResizeHandler = $('<div class="image-crop-resize-handler height-width-handler" id="image-crop-n-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize a south resize handler and place it above the selection
            // layer
            this.$sResizeHandler = $('<div class="image-crop-resize-handler height-width-handler" id="image-crop-s-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize an west resize handler and place it above the selection
            // layer
            this.$wResizeHandler = $('<div class="image-crop-resize-handler height-width-handler" id="image-crop-w-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);

            // Initialize an east resize handler and place it above the selection
            // layer
            this.$eResizeHandler = $('<div class="image-crop-resize-handler height-width-handler" id="image-crop-e-resize-handler" />')
                .css({
                    opacity: 0.8,
                    position: 'absolute'
                })
                .insertAfter(this.$selection);
        },

        calculateWorkSpaceHeight: function () {
            return this.editorHeight - this.editorSliderHeight;

        },

        setupLanguage: function () {
            this.$labelImageWidth.html(this.editorWidthInputLabel);
            this.$labelImageHeight.html(this.editorHeightInputLabel);
            this.$actionSaveEditor.html(this.editorOkButtonText);
            this.$actionCancelEditor.html(this.editorCancelButtonText);
            $(".editor-warning-message-popup").html(this.editorWarningIconText + "<div></div>"); //Could use prepend but not shure what will happend with cache and reloading the popup.
            this.$reloadEditorButton.html(this.editorReloadButtonText);
        },

        setupWindowSize: function () {
            this.$domobj.css("width", this.editorWidth - 2).css("height", this.editorHeight - 2);
            this.$workspace.css("height", this.workspaceHeight + this.cropareaBorderWidth * 2);
            this.$workspace.css("width", this.workspaceWidth + this.cropareaBorderWidth * 2);
            //Set overlay width and height
            this.$overlay.css("width", this.$workspace.cssVal('width')).css("height", this.$workspace.cssVal('height'));
        },

        resizeCropArea: function (coord) {
        	this.cropCoordinates = coord;
	        if (coord.width && coord.height) {
		        this.cropAspectRatio = coord.width / coord.height;
	        }
	        //Sets up crop area size, and outline size
            this.updateSelection();
        },

    	updateKeepAspectRatio: function (keepAspectRatio) {
    		this.KeepAspectRatio = keepAspectRatio;
		    updateResizeHandlers(this);
	    },

    	updateKeepAspectRatioIcon: function (mode) {
			var linkIcon = "a#keep-aspect-ratio";
			if (mode === "toggle") {
				$(linkIcon).toggleClass("active");
				$(linkIcon).toggleClass("inactive");
			}
			else if (mode === "set") {
				$(linkIcon).addClass("active");
				$(linkIcon).removeClass("inactive");
			}
			else if (mode === "reset") {
				$(linkIcon).removeClass("active");
				$(linkIcon).addClass("inactive");
			}
		},

        updateEffects: function (currentEffects) {
            //parse effects
            var oa = 1, rw = 0, rh = 0, cx = 0, cy = 0, z = 1, w = this.originalImageWidth, h = this.originalImageHeight, ww = this.workspaceWidth, wh = this.workspaceHeight;
            var pw = this.propertyWidth, ph = this.propertyHeight, cw = this.originalImageWidth, ch = this.originalImageHeight;
            var originalAspectRatio = w / h;

            if (pw && ph) {
                cw = pw;
                ch = ph;
            }
            else if (pw) {
                cw = pw;
                ch = h / w * pw;
            }
            else if (ph) {
                ch = ph;
                cw = w / h * ph;
            }

            var hasResize = false, hasCrop = false;

            if (currentEffects && currentEffects.length > 0) { //&& cx == 99changed logic to prevent this from running before finished.
                for (var i = 0; i < currentEffects.length; i++) {
                    var effect = currentEffects[i];
                    switch (effect.$type.split(",")[0].toLowerCase()) {
                        case "imagevault.common.data.effects.cropeffect":
                            hasCrop = true;
                            cx += effect.X || 0;
                            cy += effect.Y || 0;
                            if (effect.Width > cw && this.resizeMode == 1)
                                throw "Cannot crop smaller width than image";
                            cw = effect.Width;
                            //                            this.cropCoordinates.unscaledWidth = cw;
                            if (effect.Height > ch && this.resizeMode == 1)
                                throw "Cannot crop smaller height than image";
                            ch = effect.Height;
                            //                            this.cropCoordinates.unscaledHeight = ch;
                            break;
                        case "imagevault.common.data.effects.resizeeffect":
                            hasResize = true;
                            var sw = cw, sh = ch;
                            w = effect.Width;
                            h = effect.Height;
                            oa = sw / sh;
                            rh = Math.round(w / oa);
                            rw = Math.round(oa * h);
                            //scaleToFit
                            if (!effect.ResizeMode || effect.ResizeMode == 0) {
                                if (w && h) {
                                    //only resize to smaller images
                                    if (w <= sw || h <= sh) {
                                        var a = w / h;
                                        var aw = a * sh;
                                        if (sw > aw) {
                                            cw = w;
                                            ch = Math.round(w / oa);
                                            z = w / sw * z;
                                        } else {
                                            ch = h;
                                            cw = Math.round(oa * h);
                                            z = h / sh * z;
                                        }
                                    }
                                } else if (w) {
                                    if (w <= sw) {
                                        cw = w;
                                        ch = Math.round(w / oa);
                                        z = w / sw * z;
                                    }
                                } else if (h) {
                                    if (h <= sh) {
                                        ch = h;
                                        cw = Math.round(oa * h);
                                        z = h / sh * z;
                                    }
                                }

                                //Rescale cx and cy if resizeeffect is after a cropeffect
                                //If width or height has no value get the caluclated resize value before calculating
                                if (hasCrop) {
                                    if (oa > 1) {
                                        var scale = ((w ? w : rw) / sw);
                                        cx = cx * (z == 1 ? 1 : scale);
                                        cy = cy * (z == 1 ? 1 : scale);
                                    }
                                    else {
                                        var scale = ((h ? h : rh) / sh);
                                        cx = cx * (z == 1 ? 1 : scale);
                                        cy = cy * (z == 1 ? 1 : scale);
                                    }
                                }

                                //scale to fill
                            } else if (effect.ResizeMode == 1) {
                                if (w && h) {
                                    //only resize to smaller images
                                    //                                    if (w > sw || h > sh) {
                                    //                                        throw "Editor doesn't support digital zoom effects.";
                                    //                                    }
                                    var a = w / h;
                                    var aw = a * sh;
                                    var ah = sw / a;
                                    if (sw <= aw) {
                                        cw = w;
                                        ch = Math.round(w / oa);
                                        z = w / sw * z;
                                    } else {
                                        ch = h;
                                        cw = Math.round(oa * h);
                                        z = h / sh * z;
                                    }

                                }
                            }
                            break;
                        default:
                            throw "Effect of type " + effect.$type + " is not supported";
                    }
                }
            }

            this.cropCoordinates.unscaledWidth = cw;
            this.cropCoordinates.unscaledHeight = ch;

            // Finns property på Höjd&Bredd - rescale av cropytan., annars
            if (pw && ph) {
                if (ww <= pw || wh <= ph) {
                    var s = (pw / ww) > (ph / wh) ? pw / ww : ph / wh;

                    this.cropCoordinates.width = pw / s;
                    this.cropCoordinates.height = ph / s;
                    this.cropCoordinates.scale = s;
                } else {
                    this.cropCoordinates.width = pw;
                    this.cropCoordinates.height = ph;
                    this.cropCoordinates.scale = 1;
                }
            } // Finns property på Höjd , annars
            else if (ph) {
                if (ww <= cw || wh <= ph) {
                    var s = (cw / ww) > (ph / wh) ? cw / ww : ph / wh;

                    this.cropCoordinates.width = cw / s;
                    this.cropCoordinates.height = ph / s;
                    this.cropCoordinates.scale = s;
                } else {
                    this.cropCoordinates.width = cw;
                    this.cropCoordinates.height = ph;
                    this.cropCoordinates.scale = 1;
                }
            } // Finns property på Bredd , annars
            else if (pw) {
                if (ww <= pw || wh <= ch) {
                    var s = (pw / ww) > (ch / wh) ? pw / ww : ch / wh;

                    this.cropCoordinates.width = pw / s;
                    this.cropCoordinates.height = ch / s;
                    this.cropCoordinates.scale = s;
                } else {
                    this.cropCoordinates.width = pw;
                    this.cropCoordinates.height = ch;
                    this.cropCoordinates.scale = 1;
                }
            } // Rescalea cropytan, om nödvändigt, efter workspaceytan.
            else {
                if (ww <= cw || wh <= ch) {
                    var s = (cw / ww) > (ch / wh) ? cw / ww : ch / wh;
                    this.cropCoordinates.width = cw / s;
                    this.cropCoordinates.height = ch / s;
                    this.cropCoordinates.scale = s;
                } else {
                    this.cropCoordinates.width = cw;
                    this.cropCoordinates.height = ch;
                    this.cropCoordinates.scale = 1;
                }
            }

            // Räkna ut top och left...
            this.cropCoordinates.left = Math.round((this.workspaceWidth - this.cropCoordinates.width) / 2);
            this.cropCoordinates.top = Math.round((this.workspaceHeight - this.cropCoordinates.height) / 2);

            // In EPi 7 we do not center the image, need to change scale
            if (this.nodeInfo) {
                this.cropCoordinates.left = this.nodeInfo.x - this.nodeInfo.navPaneWidth - this.cropareaBorderWidth * 2 + this.nodeInfo.containerBorderWidth;
                this.cropCoordinates.top = this.nodeInfo.y - this.nodeInfo.menuOffset - this.cropareaBorderWidth * 2 + this.nodeInfo.containerBorderWidth;
                // If the image is too large for the content area, resize to fit

                // The actual workspace width in EPi 7 inline
                var ww = this.nodeInfo.contentWidth - this.nodeInfo.x + this.nodeInfo.navPaneWidth - this.cropareaBorderWidth * 4;
                if (this.cropCoordinates.width > ww) {
                    var factor = cw / ww;
                    this.cropCoordinates.width = cw / factor;
                    this.cropCoordinates.height = ch / factor;
                    this.cropCoordinates.scale = factor;
                }
            }

            this.cropCoordinates.leftFromImage = cx > 0 ? (cx / this.cropCoordinates.scale) : 0;
            this.cropCoordinates.topFromImage = cy > 0 ? (cy / this.cropCoordinates.scale) : 0;

            // Rita upp outline, selection etc (skapa cropytan)
            this.resizeCropArea(this.cropCoordinates);
            this.updateWidthAndHeightControls();
            updateResizeHandlers(this);

            //In med original-bilden - resizea den (eller den resizeade bilden) /Skala
            if (hasResize) {

                //If width or height has no value we set the caluclated resize value
                w = w ? w : rw;
                h = h ? h : rh;

                if (originalAspectRatio < 1)
                    z = (((hasCrop ? w : cw) / this.cropCoordinates.scale) / this.originalImageWidth);
                else
                    z = (((hasCrop ? h : ch) / this.cropCoordinates.scale) / this.originalImageHeight);

                this.zoomImage(null, z * 100);
                this.$slider.slider("value", z * 100);

                //Move ImageObj to correct position
                var outlineTop = this.$outline.cssVal('top');
                var outlineLeft = this.$outline.cssVal('left');

                var imageTop = -(this.cropCoordinates.topFromImage) + (outlineTop + this.cropareaBorderWidth);
                var imageLeft = -(this.cropCoordinates.leftFromImage) + (outlineLeft + this.cropareaBorderWidth);

                // only center image in epi6 and forms mode
                if (!this.nodeInfo) {
                    if (cw > w) imageLeft += (((cw - w) / 2) / this.cropCoordinates.scale);
                    if (ch > h) imageTop += (((ch - h) / 2) / this.cropCoordinates.scale);
                }

                this.$imageobj.css("left", Math.round(imageLeft));
                this.$imageobj.css("top", Math.round(imageTop));

                var selImageLeft = this.$imageobj.cssVal('left') - this.cropCoordinates.left - this.cropareaBorderWidth;
                var selImageTop = this.$imageobj.cssVal('top') - this.cropCoordinates.top - this.cropareaBorderWidth;
                //Move selection image to correct position
                this.$selectionImage.css("left", selImageLeft);
                this.$selectionImage.css("top", selImageTop);

            } else {
                //update originalZoomLevel if crop is changed
                var resizeRatioW = this.cropCoordinates.width / this.originalImageWidth;
                var resizeRatioH = this.cropCoordinates.height / this.originalImageHeight;

                //if resizeMode is fit, take the smallest resizeRatio, if fill, take the largest
                var resizeRatio = ((this.resizeMode == 0 && resizeRatioH < resizeRatioW) || (this.resizeMode == 1 && resizeRatioH > resizeRatioW) ? resizeRatioH : resizeRatioW);

                var top = this.cropareaBorderWidth + this.cropCoordinates.top + ((this.cropCoordinates.height) - (this.originalImageHeight * resizeRatio)) / 2;
                var left = this.cropareaBorderWidth + this.cropCoordinates.left + ((this.cropCoordinates.width) - (this.originalImageWidth * resizeRatio)) / 2;
                this.$imageobj.css("width", this.originalImageWidth * resizeRatio).css("height", this.originalImageHeight * resizeRatio).css("left", left).css("top", top);
                this.$selectionImage.width(this.originalImageWidth * resizeRatio).height(this.originalImageHeight * resizeRatio).css("left", left - this.$selection.cssVal('left')).css("top", top - this.$selection.cssVal('top'));
                this.zoomLevel = 100 * resizeRatio;
                this.originalZoomLevel = this.zoomLevel;

            }
        },

        updateSelection: function () {
            //Set croparea
            this.$outline.css("left", this.cropCoordinates.left).css("top", this.cropCoordinates.top);
            this.$outline.css("width", this.cropCoordinates.width).css("height", this.cropCoordinates.height);

            this.$selection.css({
                cursor: 'pointer',
                display: 'block',
                left: this.cropCoordinates.left + this.cropareaBorderWidth,
                top: this.cropCoordinates.top + this.cropareaBorderWidth
            })
                .width((this.cropCoordinates.width > 0) ? (this.cropCoordinates.width) : 0)
                .height((this.cropCoordinates.height > 0) ? (this.cropCoordinates.height) : 0);

            //update originalZoomLevel if crop is changed
            var resizeRatioW = this.cropCoordinates.width / this.originalImageWidth;
            var resizeRatioH = this.cropCoordinates.height / this.originalImageHeight;

            //if resizeMode is fit, take the smallest resizeRatio, if fill, take the largest
            var resizeRatio = ((this.resizeMode == 0 && resizeRatioH < resizeRatioW) || (this.resizeMode == 1 && resizeRatioH > resizeRatioW) ? resizeRatioH : resizeRatioW);

            this.originalZoomLevel = Math.round((100 * resizeRatio) * 1000) / 1000;
            //update slider with new min/value
            var val = this.$slider.slider("option", "value");

            //var originalZoomLevel = Math.round(this.originalZoomLevel * 1000) / 1000;
            var max = Math.round((100 / this.cropCoordinates.scale) * 1000) / 1000;

            this.$slider.slider("option", "min", this.originalZoomLevel);
            this.$slider.slider("option", "max", max);

            if (val < this.originalZoomLevel)
                val = this.originalZoomLevel;

            //If min and max is equal we want the slider to have the max value set.
            //ui slider does not work that way so we need a small hack.
            if (this.originalZoomLevel == max)
                this.$slider.slider("option", "min", this.originalZoomLevel - 0.01);

            this.$slider.slider("value", val);
        },

        resizeImage: function () {
            //update originalZoomLevel if crop is changed
            var resizeRatioW = this.cropCoordinates.width / this.originalImageWidth;
            var resizeRatioH = this.cropCoordinates.height / this.originalImageHeight;

            //if resizeMode is fit, take the smallest resizeRatio, if fill, take the largest
            var resizeRatio = ((this.resizeMode == 0 && resizeRatioH < resizeRatioW) || (this.resizeMode == 1 && resizeRatioH > resizeRatioW) ? resizeRatioH : resizeRatioW);

            var top = this.cropareaBorderWidth + this.cropCoordinates.top + ((this.cropCoordinates.height) - (this.originalImageHeight * resizeRatio)) / 2;
            var left = this.cropareaBorderWidth + this.cropCoordinates.left + ((this.cropCoordinates.width) - (this.originalImageWidth * resizeRatio)) / 2;
            this.$imageobj.css("width", this.originalImageWidth * resizeRatio).css("height", this.originalImageHeight * resizeRatio).css("left", left).css("top", top);
            this.$selectionImage.width(this.originalImageWidth * resizeRatio).height(this.originalImageHeight * resizeRatio).css("left", left - this.$selection.position().left).css("top", top - this.$selection.position().top);
            this.zoomLevel = 100 * resizeRatio;
            this.originalZoomLevel = this.zoomLevel;
        },

        zoomImage: function (delta, zoomLevel) {
            return zoomImageInternal(this, delta, zoomLevel);
        },

        updateCurrentEffects: function () {
            var effectArray = [];

            //Get Crop coordinates
            this.cropCoordinates.leftFromImage = Math.round((this.$outline.position().left + this.cropareaBorderWidth - this.$imageobj.position().left) * this.cropCoordinates.scale);
            this.cropCoordinates.topFromImage = Math.round((this.$outline.position().top + this.cropareaBorderWidth - this.$imageobj.position().top) * this.cropCoordinates.scale);

            //Get Crop width and height
            var cropWidth = Math.round(this.cropCoordinates.unscaledWidth > this.originalImageWidth ? this.originalImageWidth : this.cropCoordinates.unscaledWidth);
            var cropHeight = Math.round(this.cropCoordinates.unscaledHeight > this.originalImageHeight ? this.originalImageHeight : this.cropCoordinates.unscaledHeight);

            //Get Resize width and height
            var resizeWidth = Math.round(this.originalImageWidth * (this.zoomLevel / 100) * this.cropCoordinates.scale);
            var resizeHeight = Math.round(this.originalImageHeight * (this.zoomLevel / 100) * this.cropCoordinates.scale);

            if (resizeWidth > this.originalImageWidth) resizeWidth = this.originalImageWidth;
            if (resizeHeight > this.originalImageHeight) resizeHeight = this.originalImageHeight;

            //Resize Effect
            effectArray.push({ $type: "ImageVault.Common.Data.Effects.ResizeEffect,ImageVault.Common", Width: resizeWidth, Height: resizeHeight, ResizeMode: this.resizeMode == null ? 0 : this.resizeMode });

            //Crop Effect
            effectArray.push({ $type: "ImageVault.Common.Data.Effects.CropEffect,ImageVault.Common", X: this.cropCoordinates.leftFromImage, Y: this.cropCoordinates.topFromImage, Width: cropWidth, Height: cropHeight });

            this.currentEffects = effectArray;
        },

        updateWidthAndHeightControls: function () {
            this.oldImageWidthCtrlValue = Math.round(this.cropCoordinates.unscaledWidth);
            this.oldImageHeightCtrlValue = Math.round(this.cropCoordinates.unscaledHeight);

            this.$inputImageWidth.val(this.oldImageWidthCtrlValue);
            this.$inputImageHeight.val(this.oldImageHeightCtrlValue);

            //Set warning image if needed
            if (this.cropCoordinates.scale > 1) {
                this.$cropWarningImage.show();
            } else {
                this.$cropWarningImage.hide();
                this.$reloadEditorButton.hide();
            }
        },

        applyWidth: function (input) {
            var newNum = parseInt($(input).val());
            if (!newNum || newNum === this.oldImageWidthCtrlValue) {
                $(input).val(this.oldImageWidthCtrlValue);
                return;
            }
            if (this.KeepAspectRatio) {
	            var aspectRatio = this.cropCoordinates.width / this.cropCoordinates.height;
            	var newHeight = newNum / aspectRatio;
            	$("input#image-height").val(newHeight);
            	adjustCropAreaAndImage({ width: newNum, height: newHeight }, this);
            	return;
            }
            adjustCropAreaAndImage({ width: newNum }, this);
        },

        applyHeight: function (input) {
            var newNum = parseInt($(input).val());
            if (!newNum || newNum === this.oldImageHeightCtrlValue) {
            	$(input).val(this.oldImageHeightCtrlValue);
                return;
            }
            if (this.KeepAspectRatio) {
            	var aspectRatio = this.cropCoordinates.width / this.cropCoordinates.height;
            	var newWidth = newNum * aspectRatio;
            	$("input#image-width").val(newWidth);
            	adjustCropAreaAndImage({ width: newWidth, height: newNum }, this);
            	return;
            }
            adjustCropAreaAndImage({ height: newNum }, this);
        }
    };


	function updateResizeHandlers(self, action) {
        switch (action) {
            case "hide-all":
                $('.image-crop-resize-handler').each(function () {
                    $(this).css({
                        display: 'none'
                    });
                });
                break;
            default:
                var displayCorners = (!self.propertyHeight && !self.propertyWidth) ? 'block' : 'none';
                var displayHorizontal = (!self.propertyHeight) ? 'block' : 'none';
                var displayVertical = (!self.propertyWidth) ? 'block' : 'none';

                self.$nwResizeHandler.css({
                    cursor: 'nw-resize',
                    display: displayCorners,
                    left: self.cropCoordinates.left - Math.round(self.$nwResizeHandler.width() / 2),
                    top: self.cropCoordinates.top - Math.round(self.$nwResizeHandler.height() / 2)
                });

                self.$nResizeHandler.css({
                    cursor: 'n-resize',
                    display: displayHorizontal,
                    left: self.cropareaBorderWidth + self.cropCoordinates.left + Math.round(self.cropCoordinates.width / 2 - self.$neResizeHandler.width() / 2) - 1,
                    top: self.cropCoordinates.top - Math.round(self.$neResizeHandler.height() / 2)
                });

                self.$neResizeHandler.css({
                    cursor: 'ne-resize',
                    display: displayCorners,
                    left: self.cropareaBorderWidth + self.cropCoordinates.left + self.cropCoordinates.width - Math.round(self.$neResizeHandler.width() / 2) - 1,
                    top: self.cropCoordinates.top - Math.round(self.$neResizeHandler.height() / 2)
                });

                self.$wResizeHandler.css({
                    cursor: 'w-resize',
                    display: displayVertical,
                    left: self.cropCoordinates.left - Math.round(self.$neResizeHandler.width() / 2),
                    top: self.cropCoordinates.top + Math.round(self.cropCoordinates.height / 2 - self.$neResizeHandler.height() / 2) - 1
                });

                self.$eResizeHandler.css({
                    cursor: 'e-resize',
                    display: displayVertical,
                    left: self.cropareaBorderWidth + self.cropCoordinates.left + self.cropCoordinates.width - Math.round(self.$neResizeHandler.width() / 2) - 1,
                    top: self.cropCoordinates.top + Math.round(self.cropCoordinates.height / 2 - self.$neResizeHandler.height() / 2) - 1
                });

                self.$swResizeHandler.css({
                    cursor: 'sw-resize',
                    display: displayCorners,
                    left: self.cropareaBorderWidth + self.cropCoordinates.left - Math.round(self.$swResizeHandler.width() / 2),
                    top: self.cropareaBorderWidth + self.cropCoordinates.top + self.cropCoordinates.height - Math.round(self.$swResizeHandler.height() / 2) - 1
                });

                self.$sResizeHandler.css({
                    cursor: 's-resize',
                    display: displayHorizontal,
                    left: self.cropareaBorderWidth + self.cropCoordinates.left + Math.round(self.cropCoordinates.width / 2 - self.$seResizeHandler.width() / 2) - 1,
                    top: self.cropareaBorderWidth + self.cropCoordinates.top + self.cropCoordinates.height - Math.round(self.$seResizeHandler.height() / 2) - 1
                });

                self.$seResizeHandler.css({
                    cursor: 'se-resize',
                    display: displayCorners,
                    left: self.cropCoordinates.left + self.cropCoordinates.width - Math.round(self.$seResizeHandler.width() / 2) - 1,
                    top: self.cropCoordinates.top + self.cropCoordinates.height - Math.round(self.$seResizeHandler.height() / 2) - 1
                });

				if (self.KeepAspectRatio) {
					$('.height-width-handler').each(function () {
						$(this).css({
							display: 'none'
						});
					});
				}
		}
    }

    function zoomImageInternal(self, delta, zoomLevel) {
    	var oldZoom = Math.round(self.zoomLevel * 1000) / 1000;

		//Set the value of the visual slider to the desired zoomLevel
        self.$slider.slider("value", zoomLevel);

        //calculate new zoomlevel
        if (zoomLevel != null) {
            self.zoomLevel = zoomLevel;
        } else {
            self.zoomLevel += Math.round((self.zoomLevel * self.step / 100 * delta) * 1000) / 1000;
        }

        //cannot zoom more than 100 percent (no digital zoom)
        if (self.zoomLevel > Math.round((100 / self.cropCoordinates.scale) * 1000) / 1000) {
            self.zoomLevel = Math.round((100 / self.cropCoordinates.scale) * 1000) / 1000;
            self.$slider.slider("option", "max", self.zoomLevel);
            self.$slider.slider("value", self.zoomLevel);
        }
        //less that original
        if (self.zoomLevel < self.originalZoomLevel)
            self.zoomLevel = Math.round((self.originalZoomLevel * 1000)) / 1000;

        //zoom no change, ignore
        if (oldZoom == self.zoomLevel) {
            return false;
        }

        //calculate new size of image
        var width = self.originalImageWidth * (self.zoomLevel / 100);
        var height = width / self.aspectRatio;

        //if zoomed out so we are smaller than the crop area (in one direction atleast), make sure we use the same size as the crop area.
        var cw = self.cropCoordinates.width;
        var ch = self.cropCoordinates.height;

        //ResizeToFit and both sizes are smaller or ResizeToFill and any size is smaller
        if ((self.resizeMode == 0 && width < cw && height < ch) || (self.resizeMode == 1 && (width < cw || height < ch))) {
            var diffw = width - cw;
            var diffh = height - ch;
            //snap to the largest if resizeToFit, the smallest if ResizeToFill
            if ((self.resizeMode == 0 && diffw > diffh) || (self.resizeMode == 1 && diffw < diffh)) {
                width = cw;
                height = width / self.aspectRatio;
            } else {
                height = ch;
                width = height * self.aspectRatio;
            }
        }

        //calculate zoom center point (should always be the center of the crop area)
        //mx,my is the coordinate (from the imageobj top coord) where the zoom should be centered
        var mx = self.$outline.offset().left + self.$outline.width() / 2 - self.$imageobj.offset().left;
        var my = self.$outline.offset().top + self.$outline.height() / 2 - self.$imageobj.offset().top;

        //calculate new position
        var outerImagePosition = self.$imageobj.position();
        var owidth = self.$imageobj.width();
        var oheight = self.$imageobj.height();
        var ix = outerImagePosition.left;
        var iy = outerImagePosition.top;

        //new coords are based on the current coord and add the delta (adjusted with the zoom center point (mx,my))
        var x = ix + (mx / owidth) * (owidth - width);
        var y = iy + (my / oheight) * (oheight - height);

        //glue to the sides of the crop area
        if (x > self.cropCoordinates.left) {
            x = self.cropCoordinates.left + self.cropareaBorderWidth;
        }
        if (y > self.cropCoordinates.top) {
            y = self.cropCoordinates.top + self.cropareaBorderWidth;
        }

        if (y + height < self.cropCoordinates.top + self.cropCoordinates.height + self.cropareaBorderWidth) {
            y = self.cropareaBorderWidth + self.cropCoordinates.top + self.cropCoordinates.height - height;
        }

        if (x + width < self.cropCoordinates.left + self.cropCoordinates.width + self.cropareaBorderWidth) {
            x = self.cropareaBorderWidth + self.cropCoordinates.left + self.cropCoordinates.width - width;
        }

        //Center smaller images inside the croparea
        if (width < self.cropCoordinates.width) {
            x = self.cropCoordinates.left + self.cropareaBorderWidth + ((self.cropCoordinates.width) - width) / 2;
        }

        if (height < self.cropCoordinates.height) {
            y = self.cropCoordinates.top + self.cropareaBorderWidth + ((self.cropCoordinates.height) - height) / 2;
        }

        var leftAdjust = parseInt(self.$selection.position().left);
        var topAdjust = parseInt(self.$selection.position().top);

        self.$imageobj.css("width", width).css("height", height).css("left", x).css("top", y);
        self.$selectionImage.css("width", width).css("height", height).css("left", x - leftAdjust).css("top", y - topAdjust);

        return true;
    }

    function getCurrentEffect(currentEffects, type) {
        for (var i = 0; i < currentEffects.length; i++) {
            var effect = currentEffects[i];

            if (effect.$type.split(",")[0].toLowerCase() == type.toLowerCase())
                return effect;
        }
        throw "Effect not found.";
    }

    function adjustCropAreaAndImage(direction, self) {

        //make sure we have effects up to date.
        self.updateCurrentEffects();
        //Use existing effects, and adjust them to achieve the effect.
        var cropEffect = getCurrentEffect(self.currentEffects, "ImageVault.Common.Data.Effects.CropEffect");
        var resizeEffect = getCurrentEffect(self.currentEffects, "ImageVault.Common.Data.Effects.ResizeEffect");

        var changeFactor, change;

        if (direction.width && direction.width !== self.oldImageWidthCtrlValue) {
        	direction.height = direction.height || self.oldImageHeightCtrlValue;
            //Check that width is within boundaries.
            if (direction.width < 10)
                direction.width = 10;
            if (direction.width > self.originalImageWidth)
                direction.width = self.originalImageWidth;

            changeFactor = direction.width / self.oldImageWidthCtrlValue;

            if (changeFactor < 1) {
                cropEffect.X = cropEffect.X - ((direction.width - self.oldImageWidthCtrlValue) / 2);
            } else {
                //check if image needs resizing due to to wide crop area
                if (direction.width + cropEffect.X > resizeEffect.Width) {

                    if (cropEffect.X > (direction.width - self.oldImageWidthCtrlValue)) {
                        cropEffect.X -= (direction.width - self.oldImageWidthCtrlValue);

                    } else {
                        var oldW = resizeEffect.Width;
                        resizeEffect.Width = direction.width * 1.1;
                        if (resizeEffect.Width > self.originalImageWidth)
                            resizeEffect.Width = self.originalImageWidth;
                        cropEffect.X = Math.round((resizeEffect.Width - direction.width) / 2);
                        cropEffect.Y = Math.round(cropEffect.Y * (resizeEffect.Width / oldW));
                        resizeEffect.Height = resizeEffect.Height * (resizeEffect.Width / oldW);
                    }
                } else {
                    change = ((direction.width - self.oldImageWidthCtrlValue) / 2);
                    cropEffect.X = change < cropEffect.X ? cropEffect.X - change : 0;
                }
            }

            cropEffect.Width = direction.width;
        }

        if (direction.height && direction.height !== self.oldImageHeightCtrlValue) {

        	direction.width = direction.width || self.oldImageWidthCtrlValue;
            //Check that width is within boundaries.
            if (direction.height < 10)
                direction.height = 10;
            if (direction.height > self.originalImageHeight)
                direction.height = self.originalImageHeight;

            changeFactor = direction.height / self.oldImageHeightCtrlValue;

            if (changeFactor < 1) {
                cropEffect.Y = cropEffect.Y - ((direction.height - self.oldImageHeightCtrlValue) / 2);
            } else {
                if (direction.height + cropEffect.Y > resizeEffect.Height) {
                    if (cropEffect.Y > (direction.height - self.oldImageHeightCtrlValue)) {
                        cropEffect.Y -= (direction.height - self.oldImageHeightCtrlValue);
                    } else {
                        var oldH = resizeEffect.Height;
                        resizeEffect.Height = direction.height * 1.1;
                        if (resizeEffect.Height > self.originalImageHeight) {
                            resizeEffect.Height = self.originalImageHeight;
                        }

                        cropEffect.Y = Math.round((resizeEffect.Height - direction.height) / 2);
                        cropEffect.X = Math.round(cropEffect.X * (resizeEffect.Height / oldH));
                        resizeEffect.Width = resizeEffect.Width * (resizeEffect.Height / oldH);
                    }
                } else {
                    change = ((direction.height - self.oldImageHeightCtrlValue) / 2);
                    cropEffect.Y = change < cropEffect.Y ? cropEffect.Y - change : 0;
                }
            }

            cropEffect.Height = direction.height;
        }

        self.cropCoordinates.scale = 1;

        var effects = [];
        effects.push(resizeEffect);
        effects.push(cropEffect);
        self.currentEffects = effects;

        self.updateEffects(self.currentEffects);
        self.updateWidthAndHeightControls(direction);
    }

    function registerEvents(self) {
        // unbind all keydown events
        $(document).unbind("keydown");
        self.$workspace.unbind("keydown");

        // bind all keydown events for editor
        $(document).keydown(keydownEvents);
        self.$workspace.keydown(keydownEvents);

        // remove keydown events on slider if IE
        if ($.browser.msie)
            $(".ui-slider-handle").unbind('keydown');

        self.$workspace.mousewheel(function (event, delta) {
            event = $.event.fix(event);
            event.preventDefault();
            event.stopPropagation();

            zoomImageInternal(self, delta);
            self.$slider.slider("value", self.zoomLevel);
        });

        self.$outline.mousedown(function (e) {
            $(document).mousemove(moveImage);
            $(document).mouseup(releaseEvents);
            
            //return false;
        });

        self.$actionCancelEditor.click(function () {
            //window.close();
        });

        self.$reloadEditorButton.click(function () {
            self.updateCurrentEffects();
            self.updateEffects(self.currentEffects);
            self.$reloadEditorButton.hide();
            return false;
        });

        //Needed for Fancybox popup to trigger keydown events. 
        self.firstTime = true;
        self.$workspace.mousedown(function () {
            $(document).mousemove(moveImage);
            $(document).mouseup(releaseEvents);

            //Send true first time mousedown event get triggered but not when it's in a popup
            if (self.firstTime) {
                self.firstTime = false;
                if (!$.browser.msie)
                    return true;
            }

            return false;
        });

        self.$slider.mouseup(function (e) {
            e = $.event.fix(e);
            self.firstTime = true;

            e.preventDefault();
        });

        $(".image-crop-resize-handler").mousedown(function (e) {
            e = $.event.fix(e);
            e.preventDefault();
            e.stopPropagation();
            
            $(document).mousemove(resizeCropArea);
            $(document).mouseup(releaseEvents);

            self.currentHandle = e.target.id;

            updateResizeHandlers(self, "hide-all");
            updateCursor($(e.target).css("cursor"));

            return false;
        });

        if (!self.propertyWidth) {
            self.$inputImageWidth.blur(function () {
                self.applyWidth(this);
            });

            self.$inputImageWidth.focus(function () {
                self.oldImageWidthCtrlValue = parseInt($(this).val());
            });

            self.$inputImageWidth.keydown(function (e) {
                if (e.which == 13 || ($.browser.opera && e.which == 9)) {
                    self.applyWidth(this);
                    return self.callback(this, JSON.stringify(self.currentEffects));
                }

                return true;
            });

        } else {
            self.$inputImageWidth.attr("readonly", "readonly");

            self.$inputImageWidth.keydown(function (e) {
                if (e.which == 8) {
                    return false;
                }
                return true;
            });
        }

        if (!self.propertyHeight) {
            self.$inputImageHeight.blur(function () {
                self.applyHeight(this);
            });

            self.$inputImageHeight.focus(function () {
                self.oldImageHeightCtrlValue = parseInt($(this).val());
            });

            self.$inputImageHeight.keydown(function (e) {
                if (e.which == 13 || ($.browser.opera && e.which == 9)) {
                    self.applyHeight(this);
                    return self.callback(this, JSON.stringify(self.currentEffects));
                }
                
                return true;
            });

        } else {
            self.$inputImageHeight.attr("readonly", "readonly");

            self.$inputImageHeight.keydown(function (e) {
                if (e.which == 8) {
                    return false;
                }
                return true;
            });
        }

        function releaseEvents(event) {

            // Prevent the default action of the event
            event = $.event.fix(event);
            event.preventDefault();

            // Prevent the event from being notified
            event.stopPropagation();

            // Unbind the event handler to the 'mousemove' event
            $(document).unbind('mousemove');
            // Unbind the event handler to the 'mouseup' event
            $(document).unbind('mouseup');
            self.mouseY = 0;
            self.mouseX = 0;

            updateResizeHandlers(self);
            updateCursor('pointer');
        }

        function keydownEvents(e) {
            e = $.event.fix(e);
            var keyCode = e.keyCode || e.which,
                    arrow = { left: 37, up: 38, right: 39, down: 40 };

            if (!self.firstTime) {
                switch (keyCode) {
                    case arrow.left:
                        e.preventDefault();
                        e.stopPropagation();
                        moveImage(null, -1, 0);
                        break;
                    case arrow.up:
                        e.preventDefault();
                        e.stopPropagation();
                        moveImage(null, 0, -1);
                        break;
                    case arrow.right:
                        e.preventDefault();
                        e.stopPropagation();
                        moveImage(null, 1, 0);
                        break;
                    case arrow.down:
                        e.preventDefault();
                        e.stopPropagation();
                        moveImage(null, 0, 1);
                        break;
                }
            } else {

                switch (keyCode) {
                    case arrow.left:
                    case arrow.up:
                    case arrow.right:
                    case arrow.down:
                        e.preventDefault();
                        e.stopPropagation();
                        break;
                }
            }

        }

        function moveImage(e, dx, dy) {

            var imageWidth = self.$imageobj.width();
            var imageHeight = self.$imageobj.height();

            if (self.cropCoordinates.width == imageWidth && self.cropCoordinates.height == imageHeight)
                return false;

            if (e) {
                dx = (self.mouseX == 0) ? 0 : e.pageX - self.mouseX;
                dy = (self.mouseY == 0) ? 0 : e.pageY - self.mouseY;
            }
            var outerImagePosition = self.$imageobj.position();
            var newLeft = outerImagePosition.left + dx;
            var newTop = outerImagePosition.top + dy;

            //Left - right only within borders
            if (dx != 0) {
                if (newLeft > self.cropCoordinates.left + self.cropareaBorderWidth)
                    newLeft = self.cropCoordinates.left + self.cropareaBorderWidth;
                if (newLeft + imageWidth < self.cropCoordinates.left + self.cropCoordinates.width + self.cropareaBorderWidth)
                    newLeft = self.cropCoordinates.left + self.cropCoordinates.width - imageWidth + self.cropareaBorderWidth;
                if (self.cropCoordinates.width > imageWidth)
                    newLeft = outerImagePosition.left;
                self.$imageobj.css("left", newLeft);
                self.$selectionImage.css("left", newLeft - self.$selection.position().left);
            }
            //Top -bottom only within borders
            if (dy != 0) {
                if (newTop > self.cropCoordinates.top + self.cropareaBorderWidth)
                    newTop = self.cropCoordinates.top + self.cropareaBorderWidth;
                if (newTop + imageHeight < self.cropCoordinates.top + self.cropCoordinates.height + self.cropareaBorderWidth)
                    newTop = self.cropCoordinates.top + self.cropCoordinates.height - imageHeight + self.cropareaBorderWidth;
                if (self.cropCoordinates.height > imageHeight)
                    newTop = outerImagePosition.top;
                self.$imageobj.css("top", newTop);
                self.$selectionImage.css("top", newTop - self.$selection.position().top);
            }
            if (e) {
                self.mouseX = e.pageX;
                self.mouseY = e.pageY;
            }
            
            return true;
        };

        function resizeCropArea(e) {
	        e = $.event.fix(e);

            // Prevent the default action of the event
            e.preventDefault();
            // Prevent the event from being notified
            e.stopPropagation();

            var mouseposition = getMousePosition(e);
            var oldLeft;
            var oldTop;
            var oldRight;
            var xDelta;
            var x = mouseposition[0];
            var y = mouseposition[1];
            switch (self.currentHandle) {
                case 'image-crop-nw-resize-handler':
                    //don't allow negative sizes
                    if (x >= self.cropCoordinates.width)
                        x = self.cropCoordinates.width - 1;
                    if (y >= self.cropCoordinates.height)
                        y = self.cropCoordinates.height - 1;
                    oldLeft = self.cropCoordinates.left;
                    oldTop = self.cropCoordinates.top;
                    oldRight = self.cropCoordinates.left + self.cropCoordinates.width;
                    self.cropCoordinates.height = self.cropCoordinates.height - y;
                    self.cropCoordinates.width = (self.KeepAspectRatio) ? self.cropCoordinates.height * self.cropAspectRatio : self.cropCoordinates.width - x;
                    self.cropCoordinates.top = y + oldTop;
                    self.$selectionImage.css("top", self.$selectionImage.position().top - y);
                    xDelta = (oldRight - self.cropCoordinates.width) - oldLeft;
                    self.cropCoordinates.left = self.cropCoordinates.left + xDelta;
                    self.$selectionImage.css("left", self.$selectionImage.cssVal('left') - xDelta);
                    break;
                case 'image-crop-n-resize-handler':
                    //don't allow negative sizes
                    if (y >= self.cropCoordinates.height)
                        y = self.cropCoordinates.height - 1;
                    oldTop = self.cropCoordinates.top;
                    self.cropCoordinates.top = y + oldTop;
                    self.cropCoordinates.height = self.cropCoordinates.height - y;
                    self.$selectionImage.css("top", self.$selectionImage.position().top - y);
                    break;
                case 'image-crop-ne-resize-handler':
                    //don't allow negative sizes
                    if (x < 1)
                        x = 1;
                    if (y >= self.cropCoordinates.height)
                        y = self.cropCoordinates.height - 1;
                    oldTop = self.cropCoordinates.top;
                    self.cropCoordinates.top = y + oldTop;
                    self.cropCoordinates.height = self.cropCoordinates.height - y;
                    self.$selectionImage.css("top", self.$selectionImage.position().top - y);
                    self.cropCoordinates.width = (self.KeepAspectRatio) ? self.cropCoordinates.height * self.cropAspectRatio : x;
                    break;
                case 'image-crop-w-resize-handler':
                    //don't allow negative sizes
                    if (x >= self.cropCoordinates.width)
                        x = self.cropCoordinates.width - 1;
                    oldLeft = self.cropCoordinates.left;
                    self.cropCoordinates.left = x + oldLeft;
                    self.cropCoordinates.width = self.cropCoordinates.width - x;
                    //if(self.cropCoordinates.width + oldLeft > self.$imageobj.width() -)
                    self.$selectionImage.css("left", self.$selectionImage.position().left - x);
                    break;
                case 'image-crop-e-resize-handler':
                    //don't allow negative sizes
                    if (x < 1)
                        x = 1;
                    self.cropCoordinates.width = x;
                    break;
                case 'image-crop-sw-resize-handler':
                    //don't allow negative sizes
                    if (x >= self.cropCoordinates.width)
                        x = self.cropCoordinates.width - 1;
                    if (y < 1)
                        y = 1;
                    oldRight = self.cropCoordinates.left + self.cropCoordinates.width;
                    oldLeft = self.cropCoordinates.left;
                    self.cropCoordinates.height = y;
                    self.cropCoordinates.width = (self.KeepAspectRatio) ? self.cropCoordinates.height * self.cropAspectRatio : self.cropCoordinates.width - x;
                    xDelta = (oldRight - self.cropCoordinates.width) - oldLeft;
                    self.cropCoordinates.left = self.cropCoordinates.left + xDelta;
                    self.$selectionImage.css("left", self.$selectionImage.cssVal('left') - xDelta);
                    break;
                case 'image-crop-s-resize-handler':
                    //don't allow negative sizes
                    if (y < 1)
                        y = 1;
                    self.cropCoordinates.height = y;
                    break;
                case 'image-crop-se-resize-handler':
                    //don't allow negative sizes
                    if (x < 1)
                        x = 1;
                    if (y < 1)
                        y = 1;
                    self.cropCoordinates.height = y;
                    self.cropCoordinates.width = x;
                    self.cropCoordinates.width = (self.KeepAspectRatio) ? self.cropCoordinates.height * self.cropAspectRatio : x;
                    break;
            }

            self.cropCoordinates.unscaledHeight = Math.round(self.cropCoordinates.height * self.cropCoordinates.scale);
            self.cropCoordinates.unscaledWidth = Math.round(self.cropCoordinates.width * self.cropCoordinates.scale);

            if (self.cropCoordinates.unscaledHeight > self.originalImageHeight) self.cropCoordinates.unscaledHeight = self.originalImageHeight;
            if (self.cropCoordinates.unscaledWidth > self.originalImageWidth) self.cropCoordinates.unscaledWidth = self.originalImageWidth;

            self.updateWidthAndHeightControls();
            self.resizeCropArea(self.cropCoordinates);

            //show resizebutton and remove warning icon if scale is 1
            if (self.cropCoordinates.scale > 1) {
                self.$reloadEditorButton.show();
                self.$reloadEditorButton.blur();
            } else {
                self.$reloadEditorButton.hide();
            }

        };

        function getOffsetPosition(target) {

            var offset = target.offset();
            var top = offset.top;
            var left = offset.left;
            var bottom = $(window).height() - target.outerHeight();
            bottom = offset.top - bottom;
            var right = $(window).width() - target.outerWidth();
            right = offset.left - right;
            var k = {
                bottom: $(window).height() + bottom,
                right: $(window).width() + right,
                top: top,
                left: left
            };

            return k;
        };

        // Get the current mouse position relative to the image position
        function getMousePosition(event) {

            var workspace = getOffsetPosition(self.$workspace);
            var imageobj = getOffsetPosition(self.$imageobj);
            var outline = getOffsetPosition(self.$outline);

            var x = event.pageX - outline.left,
                y = event.pageY - outline.top;

            //don't pass the image top 
            if ((Math.round(outline.top) + y < Math.round(imageobj.top - self.cropareaBorderWidth)) && y <= 0)
                y = Math.round(imageobj.top - self.cropareaBorderWidth) - Math.round(outline.top);
            //or the workspace top
            if ((Math.round(outline.top) + y < Math.round(workspace.top)) && y <= 0)
                y = Math.round(workspace.top) - Math.round(outline.top);

            if (y > Math.round(imageobj.bottom - self.cropareaBorderWidth) - Math.round(outline.top))
                y = Math.round(imageobj.bottom - self.cropareaBorderWidth) - Math.round(outline.top);

            if (y > Math.round(workspace.bottom - 2 * self.cropareaBorderWidth) - Math.round(outline.top))
                y = Math.round(workspace.bottom - 2 * self.cropareaBorderWidth) - Math.round(outline.top);

            if ((Math.round(outline.left) + x < Math.round(imageobj.left - self.cropareaBorderWidth)) && x <= 0)
                x = Math.round(imageobj.left - self.cropareaBorderWidth) - Math.round(outline.left);

            if ((Math.round(outline.left) + x < Math.round(workspace.left)) && x <= 0)
                x = Math.round(workspace.left) - Math.round(outline.left);

            if (x > Math.round(imageobj.right - self.cropareaBorderWidth) - Math.round(outline.left))
                x = Math.round(imageobj.right - self.cropareaBorderWidth) - Math.round(outline.left);

            if (x > Math.round(workspace.right - 2 * self.cropareaBorderWidth) - Math.round(outline.left))
                x = Math.round(workspace.right - 2 * self.cropareaBorderWidth) - Math.round(outline.left);

            return [x, y];
        };

        // Update the cursor type
        function updateCursor(cursorType) {
            self.$workspace.css({
                cursor: cursorType
            });

            self.$outline.css({
                cursor: cursorType
            });

            self.$selection.css({
                cursor: cursorType
            });

            self.$slider.css({
                cursor: cursorType
            });
        };
    }

    ns.Editor = editor;
})(jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});
