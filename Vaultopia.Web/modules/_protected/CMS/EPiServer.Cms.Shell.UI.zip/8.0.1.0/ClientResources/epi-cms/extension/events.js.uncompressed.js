﻿define("epi-cms/extension/events", [
// Dojo
    "dojo/_base/lang",
    "dojo/keys",                                            // used to detect keyboard event
    "dojo/mouse",                                           // used to detect mouse event
    "dojo/on"                                               // used to query dom by query string inside this.domNode

], function (
// Dojo
    lang,
    keys,
    mouse,
    on

) {
    // =======================================================================
    // Helper method
    //
    function isDeleteKey(e) { return e.keyCode === keys.DELETE; }
    function isShiftKey(e) { return e.shiftKey; }
    function isF10(e) { return e.keyCode == keys.F10; }
    function isShiftF10(e) { return isShiftKey(e) && isF10(e); }
    function isMouseEvent(e) {
        return mouse.isLeft(e) || mouse.isMiddle(e) || mouse.isRight(e);
    }

    // =======================================================================
    // Common function to create a customize event
    //
    function eventHandler(type, selectHandler) {
        var handler = function (node, listener) {
            return on(node, type, function (evt) {
                if (selectHandler) {
                    return selectHandler(evt, listener);
                }
                return listener.call(this, evt);
            });
        };

        return handler;
    }

    return {
        // summary:
        //      An static class that add default events (keyboard/mouse) for common uses.
        // tags:
        //      internal

        // Support this for more convenient
        selector: on.selector,

        // =======================================================================
        // Both keyboard and mouse events
        //

        contextmenu: eventHandler("contextmenu", function (e, listener) {
            // summary:
            //      Shortcut way to listen context menu event
            // tags:
            //      public event

            listener.call(this, e);
        }),

        // =======================================================================
        // Keyboard events
        //

        keys: {
            shiftf10: eventHandler("keydown", function (e, listener) {
                // summary:
                //      Shortcut way to listen shift-f10 keydown event
                // tags:
                //      public event

                if (isShiftF10(e)) {
                    listener.call(this, e);
                }
            }),

            del: eventHandler("keydown", function (e, listener) {
                // summary:
                //      Shortcut way to listen delete keydown event
                // tags:
                //      public event

                if (isDeleteKey(e)) {
                    listener.call(this, e);
                }
            }),

            contextmenu: eventHandler("contextmenu", function (e, listener) {
                // summary:
                //      Shortcut way to listen context menu keydown event
                // tags:
                //      public event

                if (isMouseEvent(e)) { return; }
                listener.call(this, e);
            })
        },

        // =======================================================================
        // Mouse events
        //

        mouse: lang.mixin({
            contextmenu: eventHandler("contextmenu", function (e, listener) {
                // summary:
                //      Shortcut way to listen context menu event by right click
                // tags:
                //      public event

                if (isMouseEvent(e)) { listener.call(this, e); }
            })
        }, mouse)
    };
});
