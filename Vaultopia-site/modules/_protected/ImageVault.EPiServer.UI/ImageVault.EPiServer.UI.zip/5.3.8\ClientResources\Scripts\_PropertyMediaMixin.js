﻿define([
//dojo
    "dojo",
    "require",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/request/script",
    "dojo/_base/Deferred",

//epi
     "epi/epi",
     "epi/dependency"
],
function (
//dojo
    dojo,
    require,
    declare,
    lang,
    script,
    Deferred,
//epi
    epi,
    dependency
) {

    return declare(null, {
        _configstore: null,
        _authUtil: null,
        _authCheckValidUntil: null,
        //the timeout in minutes until a new auth check needs to be performed
        authCheckTimeoutSeconds: 10,
        loadScripts: function () {
            // summary:
            //      Performs initial script loading for the PropertyMedia scripts to be loaded.
            // returns:
            //      A Deferred object

            var self = this;
            //if loading already has started
            if (window.iv_jQueryDef) {
                return window.iv_jQueryDef;
            }
            if (!this._configstore) {
                var registry = dependency.resolve("epi.storeregistry");
                this._configstore = registry.get("imagevault.propertymediacommonsettingsstore");
            }
            var clientResourcePath = require.toUrl("imagevault-common") + "/";
            // Load a JavaScript library consisting of two modules
            // We construct a partial function to load the second module;
            // This simplifies the code path
            window.iv_jQueryDef = script.get(clientResourcePath + "jquery-1.6.1.min.js")
            .then(lang.hitch(this, function () {
                window.iv_jQuery = jQuery;
            }))
            // PropertyMediaList requires jQuery UI
                .then(lang.hitch(script, 'get', clientResourcePath + "jquery-ui-1.7.3.custom.min.js"))
                .then(lang.hitch(script, 'get', clientResourcePath + "jquery.fancybox-1.3.4.js"))
               
                .then(lang.hitch(script, 'get', clientResourcePath + "ImageVault.PropertyMediaCommon.js"))
                .then(lang.hitch(script, 'get', clientResourcePath + "imagevault.uicallback.js"))
                .then(lang.hitch(script, 'get', clientResourcePath + "ImageVault.PropertyMedia.js"))
                .then(lang.hitch(script, 'get', clientResourcePath + "ImageVault.PropertyMediaList.js"))
                .then(lang.hitch(script, 'get', clientResourcePath + "imagevault-client-script/scripts/imagevault-client.min.js"))
                .then(lang.hitch(this, function () {
                    window.iv_jQuery = $.noConflict(true);

                    //Register event trigger
                    epi.shell.messaging.registerLibrary("ImageVault.EPiServer_jquery", window.iv_jQuery.event, "trigger",
                        function (event, data, elem) {
                            if (typeof event == "string" && !elem) {
                                return true;
                            }
                            return false;
                        }
                    );
                    //loaded by module.config
                }))
                .then(function () {
                    //when all scripts has been loaded, load global configuration for PropertyMediaCommon.
                    //need to return the defered object or it will not be part of the waiting chain
                    return dojo.when(self._configstore.query(), function (config) {
                        lang.mixin(ImageVault.PropertyMediaCommon, config);
                    });
                });
            return window.iv_jQueryDef;
        },

        checkLoginStatus: function () {
            // summary:
            //      Performs an authentication with the ImageVault UI so that we gain a client access token in the web browser
            // returns:
            //      A Deferred object

            return this.loadScripts().then(lang.hitch(this, function () {
                var def = new Deferred();

                //init the auth util
                if (!this._authUtil) {
                    this._authUtil = new ImageVault.AuthUtil();
                }
                //check if it's time to check auth again...
                var now = new Date();
                if (this._authCheckValidUntil > now) {
                    def.resolve();
                } else {
                    //make sure that the user is logged in in ImageVault
                    this._authUtil.checkLoginStatus(null, lang.hitch(this, function (status) {
                        if (!status) {
                            def.reject("Cannot authenticate to ImageVault. Make sure that you are logged into EPiServer first.");
                        } else {
                            //update check timeout
                            now = new Date();
                            this._authCheckValidUntil = now.setSeconds(now.getSeconds() + this.authCheckTimeoutSeconds);
                            def.resolve();
                        }
                    }));
                }
                return def;
            }));
        }

    });
});
