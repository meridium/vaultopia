﻿define([
    "dojo",
    "dojo/_base/lang",
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/string",
    "dojo/_base/Deferred",
    "dojo/on",

    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

    "dijit",
    "dijit/_WidgetBase",
    "dijit/layout/_LayoutWidget",

    "epi",

    "dgrid/extensions/DnD",
    // "epi-cms/dgrid/formatters",
    "epi/dependency",
    //imagevault
    "imagevault/_PropertyMediaMixin"
], function (
    dojo,
    lang,
    declare,
    aspect,
    domConstruct,
    stringUtil,
    Deferred,
    on,

    Keyboard,
    OnDemandGrid,
    Selection,

    dijit,
    _WidgetBase,
    _LayoutWidget,

    epi,

    DnD,
    //  formatters,
    dependency,
    _PropertyMediaMixin
) {

        return declare([_WidgetBase, _LayoutWidget, _PropertyMediaMixin], {

            // _gridClass: [private] Object
            //		The class to construct the grid with.
            _gridClass: declare([OnDemandGrid, Selection, DnD, Keyboard]),

            // storeKeyName: [public] string
            //		The key of the store used to retrieve the store from the store registry.
            storeKeyName: null,

            // grid: [public] dgrid
            //		The grid that is used to display information.
            grid: null,

            // store: [public] dojo.store
            //		The store that contains the data.
            store: null,

            // dndTypes [public]
            //      The type used for drag/drop operations.
            dndTypes: ["ImageVaultMedia"],

            defaultGridMixin: null,
            // defaultGridMixin: [protected] object
            //		An object with default settings for dnd to mixin to the grid class.

            // deferred object used to signal when data is fetched
            _fetchDataDeferred: null,

            postMixInProperties: function () {
                // summary:
                //		Called after constructor parameters have been mixed-in; sets default values for parameters that have not been initialized.
                // tags:
                //		protected
                this.storeKeyName = "imagevault.browserstore";

                this.inherited(arguments);

                this.defaultGridMixin = {
                    selectionMode: "single",
                    //mousedown event added in dgrid component from 7.5
                    //needed for single click and drag function.
                    selectionEvents: "click,mousedown,dgrid-cellfocusin",
                    dndParams: {
                        creator: lang.hitch(this, this._dndNodeCreator),
                        copyOnly: true,
                        selfAccept: false
                    }
                };

                if (!this.store && this.storeKeyName) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this.store = registry.get(this.storeKeyName);
                    this.store.idProperty = "Id";
                }
            },
            startup: function () {
                // summary:
                //		Connects event handlers to common grid events.
                // tags:
                //		protected

                this.inherited(arguments);

                //override the grid.refresh and _processScroll method for checking access rights.            
                var grid = this.grid;
                var self = this;
                var orgRefresh = grid.refresh;
                grid.refresh = function () {
                    on.emit(grid.domNode, "loadingStarted", { bubbles: true, cancelable: true });

                    //make sure we are logged into IV UI before refreshing the grid
                    self.checkLoginStatus().then(function () {
                        orgRefresh.apply(grid, arguments);
                    }, function (message) {
                        self._showErrorMessage(message);
                        on.emit(grid.domNode, "error", { message: message, bubbles: true, cancelable: true });
                    });
                };
                var orgProcessScroll = grid._processScroll;
                grid._processScroll = function () {

                    //this event goes haywire when scrolling in the grid. It gets fired all the time so we better find 
                    //a more suitable place to emit the event if we want to support visual feedback on partial loading
                    //on.emit(grid.domNode, "loadingStarted", { bubbles: true, cancelable: true });

                    //make sure we are logged into IV UI before refreshing the grid
                    self.checkLoginStatus().then(function () {
                        orgProcessScroll.apply(grid, arguments);
                    }, function (message) {
                        self._showErrorMessage(message);
                        on.emit(grid.domNode, "error", { message: message, bubbles: true, cancelable: true });
                    });
                };
                grid.on("dgrid-select", dojo.hitch(this, this._onSelect));

                //when grid has been refreshed, notify the _fetchDataDeferred about the progress
                var refreshFunction = function () {
                    if (this._fetchDataDeferred) {
                        this._fetchDataDeferred.resolve();
                        this._fetchDataDeferred = null;
                    }
                    on.emit(grid.domNode, "loadingCompleted", { bubbles: true, cancelable: true });
                };
                /*dgrid-refresh-complete event added in 7.5*/
                this.grid.on("dgrid-refresh-complete", lang.hitch(this, refreshFunction));
                grid.on("dgrid-error", lang.hitch(this, function (e) {
                    var message = "Error loading data. Check connectivity to store";
                    var data = e && e.error && e.error.response ? e.error.response.data : null;
                    if (data) {
                        try {
                            data = JSON.parse(data);
                            if (data && data.isException)
                                message = data.message;
                        } catch (e) { }
                    }
                    self._showErrorMessage(message);
                    on.emit(grid.domNode, "error", { message: message });
                }));

                function fileExists(fileUrl, callback) {
                    var http = new XMLHttpRequest();
                    http.open("HEAD", fileUrl);
                    http.onreadystatechange = function () {
                        if (this.readyState === this.DONE) {
                            callback(this.status !== 404);
                        }
                    };
                    http.send();
                }

                // Add custom style for symbols if custom css file exists
                // TODO: This causes an error in logfile - path not found 404,
                // links to: http://epicms11b.local/Content/imagevault.css
                //fileExists("/Content/imagevault.css", function (exists) {
                //    if (!exists) return;
                //    var link = document.createElement("link");
                //    link.href = "/Content/imagevault.css";
                //    link.type = "text/css";
                //    link.rel = "stylesheet";
                //    link.media = "screen,print";

                //    document.getElementsByTagName("head")[0].appendChild(link);
                //});
                //trigger resize of grid when layout changes
                this.own(this.connect(this, "layout", lang.hitch(this, function () {
                    this.grid.resize();
                })));
                grid.startup();
            },

            buildRendering: function () {
                // summary:
                //		Construct the UI for this widget with this.domNode initialized as a dgrid.
                // tags:
                //		protected

                this.inherited(arguments);

                var gridSettings = lang.mixin({
                    columns: {
                        name: {
                            //Sample of how to apply custom renderer
                            renderCell: lang.hitch(this, this._renderItem)
                        }
                    },
                    //default size displays 4 items in a row so make sure that the value is divideable by 4
                    minRowsPerPage: 40,
                    //since the range isn't finite we get strange results on the top of the grid
                    //if we allow removal of farOffItems (atleast from the beginning of the grid)
                    farOffRemoval: Infinity,
                    store: this.store,
                    dndSourceType: this.dndTypes,
                    sort: [{ property: 'Name', descending: true }]
                }, this.defaultGridMixin);

                this.grid = new this._gridClass(gridSettings, this.domNode);
                this.grid.renderRow = this._renderRow;
                this.grid.set("showHeader", false);

                dojo.subscribe("/dnd/drop", lang.hitch(this, function (source, nodes, copy, target) {
                    //only listen to your own events
                    if (source.grid === this.grid) {
                        this.grid.deselect(nodes[0]);
                    }
                }));
            },

            _renderRow: function (item, options) {

                var isVideo = item.OriginalItem &&
                    item.OriginalItem.ContentType &&
                    item.OriginalItem.ContentType.toLowerCase().substring(0, "video/".length) === "video/";

                // create div that contains image
                var thumbNailContainer = dojo.create("div");

                // Wrapper for symbols on media
                var symbolsWrapper = document.createElement("div");

                // Set classname on symbols wrapper
                symbolsWrapper.className = "media-library-symbols";

                // Append symbols placeholder
                thumbNailContainer.appendChild(symbolsWrapper);

                // Function that creates symbol
                function createSymbol(names, values, cssClass, symbolsWrapper) {

                    // Container for symbol
                    var symbolHtml = document.createElement("span");

                    // Symbol html string
                    var symbolString = "<div class=\"media-library-symbol\">\
                    <span class=\"media-library-symbol-icon icon icon-" + cssClass + "\"><div class=\"media-library-symbol-description\">";
                    if (names != null) {
                        // Loop throught every name
                        for (var i = 0; i < names.length; i++) {
                            var name = (names[i] || "").toString();
                            if (!name) continue;
                            var value = (values[i] || "").toString();
                            if (!value) continue;

                            // Try parse value as date
                            if (value.indexOf("/Date(") !== -1) {
                                value = value.replace("/Date(", "").replace(")/", "");
                                var date = new Date(parseInt(value));
                                value = date.getFullYear() + "-" + (date.getMonth() < 10 ? 0 : "") + (date.getMonth() + 1) + "-" + ((date.getDate() + 1) < 10 ? 0 : "") + date.getDate();
                            }

                            // Name and description for symbol (metadata definition name and metadata value)
                            symbolString += "<strong>" + name + "</strong><p>" + value + "</p></br>";
                        }
                        symbolHtml.addEventListener("mouseover", (e) => {
                            e.target.querySelector(".media-library-symbol-description").classList.remove("bottom-right", "bottom-left", "top-right", "top-left");
                            var offsetLeft = e.target.parentElement.parentElement.parentElement.offsetLeft;
                            var offsetTop = e.target.parentElement.parentElement.parentElement.parentElement.offsetTop - e.target.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.scrollTop;
                            if (offsetLeft < 100 && offsetTop < 100) {
                                e.target.querySelector(".media-library-symbol-description").classList.add("bottom-right");
                            } else if (offsetLeft >= 100 && offsetTop < 100) {
                                e.target.querySelector(".media-library-symbol-description").classList.add("bottom-left");
                            } else if (offsetLeft < 100 && offsetTop >= 100) {
                                e.target.querySelector(".media-library-symbol-description").classList.add("top-right");
                            } else {
                                e.target.querySelector(".media-library-symbol-description").classList.add("top-left");
                            }
                            e.target.querySelector(".media-library-symbol-description").classList.add("description-visible");
                        });

                        symbolHtml.addEventListener("mouseout", (e) => {
                            e.target.querySelector(".media-library-symbol-description").classList.remove("description-visible");
                        });
                    }
                    symbolString += "</div></span></div>";

                    symbolHtml.innerHTML = symbolString;

                    symbolsWrapper.appendChild(symbolHtml);
                }

                // Video icon
                if (isVideo) {
                    createSymbol(null, null, "video-media", symbolsWrapper);
                }

                // Agreement icons (from API)
                var legalBasis = {
                    1: "Consent",
                    2: "Agreement",
                    3: "Legal Obligation",
                    4: "Protect Registrants Vital Interests",
                    5: "Public Interest",
                    6: "Legitimate Interest"
                };

                var validToDateStatus = {
                    1: "Valid",
                    2: "Expired",
                    5: "SoonExpired"
                };

                for (var a in item.Agreements) {
                    var agreementBasis = legalBasis[item.Agreements[a].LegalBasis];
                    var validToDate = validToDateStatus[item.Agreements[a].ValidToDateStatus];
                    createSymbol([item.Agreements[a].AgreementIdentifier], [agreementBasis], validToDate.toLowerCase(), symbolsWrapper);
                }

                // Icons/agreements (from assets)
                // Agreements most important (should be on top/far right)
                if (item.Symbols && item.Symbols.length > 0) {
                    var sortedSymbols = item.Symbols.filter(x => { return x.Symbol !== "video-media" && x.Symbol !== "shared-media"; }).sort(function (x, y) {
                        if (x === "expired" || x === "soonexpired" || x === "valid") {
                            return 1;
                        } else {
                            return -1;
                        }
                    });

                    for (var s in sortedSymbols) {
                        var current = sortedSymbols[s];

                        var cssClass = current.Symbol;
                        var symbolNames = [];
                        var symbolValues = [];
                        if (current.Info && current.Info.length > 0) {
                            symbolNames = current.Info.map(i => i.Name);
                            symbolValues = current.Info.map(i => i.Value);
                        }

                        createSymbol(symbolNames, symbolValues, cssClass, symbolsWrapper);

                    }
                }


                // Create the div and place it inside thumbNailContainer
                var element = {
                    width: "110",
                    height: "110",
                    src: item.Thumbnail.Url,
                    title: item.Name || ""
                };

                if (item.ThumbnailRetina) {
                    element.srcset = item.ThumbnailRetina.Url + " 2x";
                }

                function buildMetadataTables(metadataList, definitionList) {
                    var arr = [];
                    metadataList.filter(function (x) { return x.Value; }).map(function (x) {
                        var index = x.DefinitionId || x.MetadataDefinitionId;
                        var definitionType = definitionList[index].Key;

                        var tableRow = document.createElement("tr");
                        var cellName = document.createElement("td");
                        cellName.classList.add("metadata-name");
                        var cellValue = document.createElement("td");
                        cellValue.classList.add("metadata-value");


                        cellName.innerText = definitionList[index].Value;
                        cellValue.innerText = x.Value;
                        tableRow.appendChild(cellName);
                        tableRow.appendChild(cellValue);

                        if (arr.filter(function (x) { return x.name === definitionType; }).length < 1) {
                            // Create new table to hold this data
                            var table = document.createElement("table");
                            table.classList.add("metadata-table", definitionType.toLowerCase());
                            var headerRow = document.createElement("tr");
                            var headerText = document.createElement("th");
                            headerText.colSpan = "2";
                            headerText.innerText = definitionType;
                            headerRow.appendChild(headerText);
                            table.appendChild(headerRow);
                            arr.push({
                                "name": definitionType,
                                "table": table
                            });
                        }

                        arr.filter(function (x) { return x.name === definitionType; })[0].table.appendChild(tableRow);
                    });

                    // System first
                    var sorted = arr.sort(function (x, y) {
                        if (x.name.toLowerCase() === "system" || x.name.toLowerCase() === "user") {
                            return -1;
                        }
                        return 1;

                    });

                    return sorted;

                }

                // Preview
                function showPreviewPanel(e) {
                    // remove
                    this.parentElement.parentElement.querySelectorAll(".preview-body").forEach(function (i) {
                        document.removeChild(i);
                    });

                    var bodyDiv = document.createElement("div");
                    bodyDiv.classList.add("preview-body");

                    var wrapperDiv = document.createElement("div");
                    wrapperDiv.classList.add("preview-wrapper");

                    // preview img
                    var previewImage = document.createElement("img");
                    previewImage.src = item.PreviewImage.Url;
                    previewImage.classList.add("preview-image");

                    if (item.PreviewImageRetina) {
                        previewImage.srcset = item.PreviewImageRetina.Url + " 2x";
                    }

                    wrapperDiv.appendChild(previewImage);

                    // Metadata panel
                    let metadataPanel = document.createElement("div");
                    metadataPanel.classList.add("metadata-panel");

                    // Metadata from Azure search
                    var metadataTables = buildMetadataTables(item.AzureMetadata || item.Metadata, item.MetadataDefinitions);
                    let tableWrapper = document.createElement("div");
                    tableWrapper.classList.add("table-wrapper");

                    for (var i in metadataTables) {
                        tableWrapper.appendChild(metadataTables[i].table);
                    }

                    wrapperDiv.appendChild(tableWrapper);

                    // Close when clicking outside image
                    bodyDiv.addEventListener("click", function (e) {
                        bodyDiv.parentElement.removeChild(bodyDiv);
                    });

                    // Dont close when clicking on wrapper
                    wrapperDiv.addEventListener("click", function (e) {
                        e.cancelBubble = true;
                        e.stopPropagation();
                    });

                    bodyDiv.appendChild(wrapperDiv);

                    this.parentElement.parentElement.appendChild(bodyDiv);
                }

                var previewOverlay = document.createElement("span");
                previewOverlay.classList.add("icon", "icon-search");
                previewOverlay.title = "Preview";
                previewOverlay.addEventListener("click", showPreviewPanel);

                thumbNailContainer.appendChild(previewOverlay);

                dojo.create("img", element, thumbNailContainer);

                return thumbNailContainer;
            },

            fetchData: function (queryParameters) {
                //  summary:
                //      Fetches the data to the grid and updates it according to the queryParameters.
                //  queryParameters:
                //      The parameters to send to the store
                //  returns:
                //      A Deferred object to be invoked when fetching is completed.

                var oldFetchDataDeferred = this._fetchDataDeferred;
                this._fetchDataDeferred = new Deferred();

                //if more listeners are listening, make sure that we queue them up
                if (oldFetchDataDeferred) {
                    this._fetchDataDeferred.then(function (value) {
                        oldFetchDataDeferred.resolve(value);
                    });
                }

                this.grid.set("queryOptions", { ignore: ["query"], sort: [{ attribute: "Name", descending: true }] });
                this.grid.set("query", queryParameters);

                return this._fetchDataDeferred;
            },

            _onSelect: function (e) {
                // summary:
                //		Publish a context request when a version is selected in the list.
                // tags:
                //		private

                //Do something here..
            },

            restore: function () {
                // summary: Restore component visuals
                this.resize();
            },

            _showErrorMessage: function (errorMessage) {
                this.grid.cleanup();

                // There is no public method for setting messages, so use the same style as dgrid.
                this.grid.contentNode.innerHTML = "<div class='errorMessage'>" +
                    "<p class='heading'>Error</p>" +
                    "<p class='message'>[" + errorMessage + "]</p>" +
                    "</div>";
            },

            _dndNodeCreator: function (item, hint) {
                // summary:
                // Custom DnD avatar creator method

                var template = "<div><img src=\"${imageUrl}\" alt=\"${alt}\"/></div>";
                var node = domConstruct.toDom(stringUtil.substitute(template, {
                    alt: item.Name || "ImageVault media",
                    imageUrl: item.Thumbnail.Url
                }));

                return {
                    "node": node,
                    "type": this.dndTypes,
                    "data": item,
                    //HACK, we replaced episervers Avatar class and by supplying this property we signal it to do standard dojo Avatar handling instead.
                    supressEPiAvatarCreation: true
                };
            }
        });
    });