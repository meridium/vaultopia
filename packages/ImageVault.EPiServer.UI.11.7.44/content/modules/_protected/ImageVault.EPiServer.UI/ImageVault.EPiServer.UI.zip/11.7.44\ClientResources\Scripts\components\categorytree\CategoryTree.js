define("imagevault/components/categorytree/CategoryTree", [
    "epi",
    "dojo",
    "dojo/_base/declare",
    "dijit/Tree",
    "imagevault/components/categorytree/_CategoryTreeNode",
    "imagevault/components/categorytree/CategoryTreeStoreModel",
    "epi/dnd/Source"
], function (epi, dojo, declare, Tree, _CategoryTreeNode, CategoryTreeStoreModel, Source) {

    return declare([Tree, Source], {
        // summary:
        //    The ImageVault Category tree. (borrowed from EPiServer category tree)
        //
        // description:
        //    The page tree shows the EPiServer Category  page tree using a REST store to fetch the data.
        //
        // tags:
        //    public

        // Hide the root node.
        showRoot: false,

        postMixInProperties: function () {
            // summary:
            //		Post mixin initializations.
            // tags:
            //		protected

            this.inherited(arguments);

            if (!this.model) {
                this.model = new CategoryTreeStoreModel();

                this.persist = false;
            }
        },

        startup: function () {
            // summary:
            //		Widget startup.
            // tags:
            //		protected
            this.inherited(arguments);

            // disabling multiselect in tree
            this.dndController.singular = true;
        },

        buildNodeFromTemplate: function (args) {
            // summary:
            //		Build tree node from the given template.
            // args: Object
            //      Tree node creation arguments
            // tags:
            //		extension

            return new _CategoryTreeNode(args);
        },

        _createTreeNode: function (/*Object*/args) {
            // summary:
            //		Overridable function to create tree node.
            // args: Object
            //      Tree node creation arguments
            // tags:
            //		extension

            var treeNode = this.buildNodeFromTemplate(args);
            this.connect(treeNode, "onCheckBoxChange",
                        dojo.hitch(this, function (isChecked, item) {
                            this.onTreeNodeCheckBoxChange(isChecked, item);
                        }));

            this.onTreeNodeCreated(treeNode, args.item);

            return treeNode;
        },

        onTreeNodeCreated: function (treeNode, item) {
            //summary:
            //    onTreeNodeCreated event.
            //
            // treeNode: the tree node.
            //
            // item: the tree node item.
            //
            // tags:
            //    public

        },

        onTreeNodeCheckBoxChange: function (isChecked, item) {
            //summary:
            //    onTreeNodeCheckBoxClicked event.
            //
            // isChecked: true if the check box is checked,otherwise false.
            //
            // item: the tree node item.
            //
            // tags:
            //    public
        },

        getTreeNodeById: function (categoryId) {
            //summary:
            //    get the tree node by category id.
            //
            // categoryId: the category id.
            //
            // tags:
            //    public

            var nodes = this.tree.getNodesByItem(categoryId.toString());
            if (!nodes) {
                return null;
            }

            return nodes[0];
        },

        unselectChildNodes: function (selectedNodes) {
            for (var i = 0; i < selectedNodes.length; i++) {
                selectedNodes[i].setCheckAttribute(false);

                this.unselectChildNodes(selectedNodes[i].getChildren());
            }
        }
    });

});
