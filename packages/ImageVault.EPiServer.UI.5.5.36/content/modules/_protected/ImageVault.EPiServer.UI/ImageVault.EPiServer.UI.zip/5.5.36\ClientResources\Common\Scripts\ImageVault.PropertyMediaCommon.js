﻿(function ($, ns) {


    var ivUiAuthUtil = function (config) {
        $.extend(this, config);
        return this;
    };
    ivUiAuthUtil.prototype = {
        _callbackCalled: false,
        _timer: null,
        timeout: 20000,
        //Main method to check if current user is logged into ImageVault Ui
        //will call callback upon complete check whith true if logged in (or successfully performed login)
        //or false if login is not possible
        checkLoginStatus: function (testUrl, callback) {
            testUrl = testUrl || ImageVault.PropertyMediaCommon.ivUiAuthUrl;
            //no testUrl, then test is not needed
            if (!testUrl) {
                //throw "testUrl is not supplied";
                callback("Loginstatus not tested. ImageVault.PropertyMediaCommon.ivUiAuthUrl not set");
                return;
            }
            //IE caches the requests if we don't add the qs parameter
            testUrl = testUrl + "?doNotCache=" + (new Date()).getTime();
            var self = this;
            this._callbackCalled = false;
            if (this._timer) {
                clearInterval(this._timer);
            }
            testUrl = ImageVault.Client.prototype._makeAbsoluteUrl(testUrl);
            this._checkLoginStatus(testUrl, function (status) { self._callCallback(callback, status); });
        },

        _callCallback: function (callback, status) {
            //clear timer if any
            if (this._timer) {
                clearInterval(this._timer);
                this._timer = null;
            }
            //callback already called, aborting
            if (this._callbackCalled) { return; }

            this._callbackCalled = true;
            callback(status);
        },
        _getNoOfCallbacksForAuth: function () {
            if (navigator.userAgent.indexOf("Firefox") != -1)
                return 1;
            return 2;
        },

        _checkLoginStatus: function (testUrl, callback) {
            var self = this;
            //first try to access auth url with ajax.
            $.ajax({
                url: testUrl,
                complete: function (xhr) {
                    //did we get to the episerver loginpage? Then we cannot continue
                    if (xhr.responseText.indexOf("login.aspx") > 0) {
                        callback(false);
                        //or did we come to the ipd?, then we need to try to login
                    } else if (xhr.responseText.indexOf("RequestSecurityTokenResponseCollection") > 0) {
                        //for most browsers the iframe load event is fired twice during login
                        var timesLoaded = 0;
                        var timesToLoad = self._getNoOfCallbacksForAuth();

                        var $iframe = $("<iframe style='display:none'/>").attr("src", testUrl).load(function () {
                            if (++timesLoaded < timesToLoad) {
                                //if we get here in pass 2 and callback already has been called, give up
                                if (self._callbackCalled) {
                                    return;
                                }
                                //we have already tried to try again and timeout has passed so we abort
                                if (self._timer) {
                                    callback(false);
                                } else {
                                    //Setup timeout to return timeout message if failed...
                                    self._timer = setTimeout(function () {
                                        callback(false);
                                    }, self.timeout);
                                }
                            } else {
                                //second pass we have completed authentication (hopefully)
                                if ($iframe) {
                                    $iframe.remove();
                                    $iframe = null;
                                }
                                callback(true);
                            }
                        });
                        //add iframe to start processing
                        $('body').append($iframe);
                    } else {
                        //						log("already logged in");
                        callback(true);

                    }
                }
            });
        }
    };
    //export to ImageVault namespace
    ns.AuthUtil = ivUiAuthUtil;

    var authUtil = new ivUiAuthUtil();

    var pmc = function () {
        return this;
    };

    pmc.prototype = {
        //Properties
        //uri to ImageVault UI
        uri: null,
        //confirm message for the clear button
        clearConfirmMessage: null,
        //uri to the default thumb icon
        defaultIconUri: null,
        //the id of the value field (that is stored in the property)
        hiddenFieldId: null,
        //the id of the thumbnailcache field
        thumbnailHiddenFieldId: null,
        //id of the format id that should be requested as thumbnail from IV
        thumbnailFormatId: null,
        //id of the clear link
        removeLinkId: null,
        //the target width of the control (0 is not set)
        targetWidth: 0,
        //the target height of the control (0 is not set)
        targetHeight: 0,
        //the target ResizeMode:0 ScaleToFit, 1 ScaleToFill
        resizeMode: 0,
        //settings for the thumbnailsize to display in the edit mode
        propertyThumbnailWidth: null,
        propertyThumbnailHeight: null,
        propertyThumbnailResizeMode: 0,
        //is the control readonly? (cannot modify using user controls)
        readOnly: false,
        //methods
        //converts the data item (from the IV UI) to a mediaCacheItem
        createMediaCache: function (data, callback) {
            if (data.MediaConversions == null || data.MediaConversions.length == 0) {
                throw 'Missing requested MediaConversion';
            }
            var thumb = data.MediaConversions[0];
            var org = data.MediaConversions[1];
            //since we are not sure which format is which, check the names. Original should be called original
            if (!/^original$/i.test(org.MediaFormatName)) {
                var tmp = thumb;
                thumb = org;
                org = tmp;
            }
            //Creates the return value that consists of the orignal info plus the Thumb and a editor format (wrongly named Original)
            var createReturnValue = function (org, thumb, editorMedia) {
                //create the cache (represents the MediaCacheItem)
                if (!editorMedia) {
                    editorMedia = org;
                }
                return {
                    Id: data.Id,
                    VaultId: data.VaultId,
                    VaultRole: 1, //Atleast view access when selected
                    Original: {
                        ContentType: editorMedia.ContentType,
                        Width: editorMedia.Width,
                        Height: editorMedia.Height,
                        Url: editorMedia.Url
                    },
                    Thumb: {
                        ContentType: thumb.ContentType,
                        Width: thumb.Width,
                        Height: thumb.Height,
                        Url: thumb.Url
                    },
                    //Return the propertyList position with the cachedata.
                    PropertyListIndex: data.propertyListIndex,
                    OriginalFormatContentType: org.ContentType,
                    OriginalFormatUrl: org.Url
                };
            };

            //if org.Width is missing, create a new request where we get the Large thumbnail and uses that as original (Editor webmedia/thumbnail)...
            if (!org.Width) {
                this.getMedia({ Id: data.Id }, org.ContentType, 0, 0, 0, function (largeThumbData) {
                    callback(createReturnValue(org, thumb, largeThumbData.MediaConversions[0]));
                });
            } else {
                callback(createReturnValue(org, thumb));
            }

        },
        //
        isVideo: function (mediaCache) {
            return mediaCache && mediaCache.OriginalFormatContentType && mediaCache.OriginalFormatContentType.indexOf("video/") === 0;
        },
        //checks if the supplied mediaCache item is editable according to the settings of the property
        //returns null if
        getEditableStatusMessage: function (mediaCache) {
            if (!mediaCache)
                return "";
            if (mediaCache.Thumb && mediaCache.Thumb.Url && mediaCache.Thumb.Url == this.defaultIconUri)
                return "";
            if (!mediaCache.VaultRole)
                return ImageVault.PropertyMediaCommon.msg.editorDisabledNoAccessToMedia;
            /*
			**	2013-11-28 / RW
			**	We are unlocking the possibility to edit non-image-originals (shown as default icons) until we can distinguish
			**	the difference between a default icon and a converted image.
			if (!mediaCache.Original || !/^image\//i.test(mediaCache.Original.ContentType))
			return ImageVault.PropertyMediaCommon.msg.editorDisabledOriginalFormatNotSupported;
			*/
            //scaleToFit
            if (this.resizeMode == 0 && (
                //If both w&h is limiting, we have an error if both dimensions is smaller (or equal) than the target
				((this.targetWidth && this.targetHeight) && (this.targetWidth >= mediaCache.Original.Width && this.targetHeight >= mediaCache.Original.Height)) ||
                //if only one dimension is specified we have an error if the original is smaller (or equal) the target
				(this.targetWidth && this.targetWidth >= mediaCache.Original.Width) ||
				(this.targetHeight && this.targetHeight >= mediaCache.Original.Height))
                && !this.isVideo(mediaCache)
				)
                return ImageVault.PropertyMediaCommon.msg.editorDisabledOriginalToSmall;
            //ScaleToFill, if any dimension is larger, media is to small
            if (this.resizeMode == 1 && (this.targetWidth >= mediaCache.Original.Width || this.targetHeight >= mediaCache.Original.Height))
                return ImageVault.PropertyMediaCommon.msg.editorDisabledOriginalToSmall;
            return null;
        },
        //checks if the supplied mediaCache item is editable according to the settings of the property
        isEditable: function (mediaCache) {
            //if mediaCache is null we are not editable and if we have a editable status message then we are not editable, 
            if (mediaCache && mediaCache.Thumb && mediaCache.Thumb.Url == this.defaultIconUri)
                return false;

            //Special treatment for video when it is smaller than propertysettings(#3321)
            //We must also check that access is allowed (#3348)
            if (this.isVideo(mediaCache) && mediaCache.VaultRole) {
                return true;
            }

            return (mediaCache ? (this.getEditableStatusMessage(mediaCache) ? false : true) : false);
        },
        createMessagePopup: function ($parent, mediaCache) {
            var message = this.getEditableStatusMessage(mediaCache);
            //ignore popup if it isieditable or message is not set
            if (!message)
                return null;
            var $popup = $('<div class="propertymedia-message-popup"><div></div></div>');
            $("div", $popup).text(message);
            $parent.append($popup);
            return $popup;
        },
        //gets the vaultrole for the current user 
        //vaultId; the id of the vault to check
        //callback; the callback function that takes the vaultRole as parameter
        getVaultRoleForVault: function (vaultId, callback) {
            var client = this.getClient();
            var parameters = {
                query: {
                    Filter: { Id: vaultId },
                    Populate: { CurrentUserRole: true }
                }
            };
            client.json("VaultService/Find", parameters, function (v) {
                var vaultRole = 0;
                if (v && v.length == 1 && v[0].Id == vaultId)
                    vaultRole = v[0].CurrentUserRole;
                callback(vaultRole);
            });
        },
        //Gets the client for communicating with core
        getClient: function () {

            if (ImageVault.ClientInstance == undefined)
                ImageVault.ClientInstance = new ImageVault.Client({
                    core: ImageVault.PropertyMediaCommon.ivCoreProxy,
                    authMethod: "none"
                });;

            return ImageVault.ClientInstance;
        },
        //Gets the string value stored in the hidden field
        getHiddenFieldValue: function () {
            var $hiddenField = $('#' + this.hiddenFieldId);
            return $hiddenField.val();
        },
        setHiddenFieldValue: function (val) {
            var $hiddenField = $('#' + this.hiddenFieldId);
            $hiddenField.val(val);
        },
        //called when a user clicks the insert button in IVUI(override this in subclass)
        callback: function (data) { },
        //callback for updating effects in selected media
        storeEffects: function (effects, callbackParams) { },
        _getWindowName: function (name) {
            //IE don't handle window names with - in them
            name = (name || "noname").replace(new RegExp("-", "g"), '_');
            return name;
        },
        showSpinner: function ($elem) {
            if (this.spinner)
                this.hideSpinner();
            var opts = {
                lines: 13, // The number of lines to draw
                length: 8, // The length of each line
                width: 3, // The line thickness
                radius: 10, // The radius of the inner circle
                corners: 1, // Corner roundness (0..1)
                rotate: 0, // The rotation offset
                color: '#fff', // #rgb or #rrggbb
                speed: 1, // Rounds per second
                trail: 60, // Afterglow percentage
                shadow: true, // Whether to render a shadow
                hwaccel: true, // Whether to use hardware acceleration
                className: 'spinner', // The CSS class to assign to the spinner
                zIndex: 2e9, // The z-index (defaults to 2000000000)
                top: 'auto', // Top position relative to parent in px
                left: 'auto' // Left position relative to parent in px
            };
            this.spinner = new Spinner(opts).spin($elem.get(0));
        },
        hideSpinner: function () {
            if (this.spinner) {
                this.spinner.stop();
                this.spinner = null;
            }
        },
        openEditor: function (mediaCache, mediaReference, callbackParams, keepAspectRatio, useInline, propertyMediaOverlaySelectorInstance, isVideo, format) {
            if (this.readOnly)
                return;
            var self = this;
            //tried to use the org url as auth test but it halted sometimes...
            authUtil.checkLoginStatus(/*mediaCache.Original.Url*/null,
				function (status) {
				    if (!status)
				        alert("Cannot open editor, need to be logged into ImageVault first");
				    self._openEditor(mediaCache, mediaReference, callbackParams, keepAspectRatio, useInline, propertyMediaOverlaySelectorInstance, isVideo, format);
				});
        },
        _getWindowInnerSize: function () {
            var w = window, d = document, e = d.documentElement, g = d.getElementsByTagName('body')[0], x = w.innerWidth || e.clientWidth || g.clientWidth, y = w.innerHeight || e.clientHeight || g.clientHeight;
            return { width: x, height: y };
        },
        _openEditor: function (mediaCache, mediaReference, callbackParams, keepAspectRatio, useInline, propertyMediaOverlaySelectorInstance, isVideo, format) {
            var self = this;

            var id = mediaReference.Id || mediaReference.id;
            //debug to supply effects on hash 
            //#C|10|10|100|100|R|50|55|1
            var hash = window.top.location.hash;
            if (hash && hash.length > 1) {
                var effects = [];
                var a = hash.substr(1).split("|");
                for (var i = 0; i < a.length; i++) {
                    switch (a[i]) {
                        case "C":
                            effects.push({ $type: "ImageVault.Common.Data.Effects.CropEffect, ImageVault.Common", X: a[++i], Y: a[++i], Width: a[++i], Height: a[++i] });
                            break;
                        case "R":
                            effects.push({ $type: "ImageVault.Common.Data.Effects.ResizeEffect, ImageVault.Common", Width: a[++i], Height: a[++i], ResizeMode: a[++i] });
                            break;
                        default:
                    }
                }
                if (effects.length > 0) {
                    this.storeEffects(effects, callbackParams);
                    return;
                }
            }
            this.hideSpinner();
            var name = this._getWindowName(this.hiddenFieldId) + "_editor";

            var url = ImageVault.PropertyMediaCommon.editorUri;
            var effectsString = (mediaReference.Effects) ? JSON.stringify(mediaReference.Effects) : "[]";
            //callback that is used to initialize editor when it is loaded

            var winSize = this._getWindowInnerSize();
            //adjust max size (if window is greater, don't overgrow....)
            if (winSize.width > 1400) winSize.width = 1400;
            if (winSize.height > 900) winSize.height = 900;
            //defaultEditorSize is only used with popup since win does not contain innerWidth/innerHeight
            var defaultEditorSize = { width: winSize.width, height: winSize.height };

            var editorWidth = $('.epi-editorViewport-previewBox .dijitReset').width() || $(document).width();
            var editorHeight = $('.epi-editorViewport-previewBox').height() || $(document).height() - self.nodeCoords.menuOffset;
          
            var resizeMode = 0;

            // If format aspectRatio is set, then resizeMode must be 1!
            if (format && format.AspectRatio) {
                resizeMode = 1;
            }

            var initEditorCallback = function (win, beforeStoreEffectsCallback) {
                var params;

                if (!useInline) {
                    params = {
                        id: id,
                        //settings regarding the editor window
                        editorSettings: {
                            width: win.innerWidth || defaultEditorSize.width,
                            height: win.innerHeight || defaultEditorSize.height
                        },
                        //settings for communicating with core
                        coreSettings: {
                            client: self.getClient(),
                            mediaUrlBase: ImageVault.PropertyMediaCommon.mediaUrlBase
                        },
                        languageSettings: {
                            editorWidthInputLabel: ImageVault.PropertyMediaCommon.msg.editorWidthInputLabel,
                            editorHeightInputLabel: ImageVault.PropertyMediaCommon.msg.editorHeightInputLabel,
                            editorOkButtonText: ImageVault.PropertyMediaCommon.msg.editorOkButtonText,
                            editorCancelButtonText: ImageVault.PropertyMediaCommon.msg.editorCancelButtonText,
                            editorWarningIconText: ImageVault.PropertyMediaCommon.msg.editorWarningIconText,
                            editorReloadButtonText: ImageVault.PropertyMediaCommon.msg.editorReloadButtonText,
                            editorLoadErrorText: ImageVault.PropertyMediaCommon.msg.editorLoadErrorText,
                            title: ImageVault.PropertyMediaCommon.msg.title
                        },
                        //current effects applied on the image
                        currentEffects: effectsString,
                        //end format (can be null)
                        targetFormat: {
                            width: isVideo ? propertyMediaOverlaySelectorInstance.width : self.targetWidth,
                            height: isVideo ? propertyMediaOverlaySelectorInstance.height : self.targetHeight,
                            resizeMode: isVideo ? propertyMediaOverlaySelectorInstance.resizeMode : self.resizeMode
                        },
                        //original image format
                        originalFormat: {
                            width: mediaCache.Original.Width,
                            height: mediaCache.Original.Height,
                            url: mediaCache.Original.Url,
                            contentType: mediaCache.OriginalFormatContentType
                        },
                        //return an array of effects that should be applied to the media

                        callback: function (eff) {
                            if (beforeStoreEffectsCallback) {
                                beforeStoreEffectsCallback();
                                win.close();
                            }
                            if (eff && eff.length > 0) {
                                eff = JSON.parse(eff);
                                self.storeEffects(eff, callbackParams);
                                win.close();
                            } else {
                                win.close();
                                $.event.trigger("/imagevault/propertymediacommon/editorclosed");
                            }

                        },
                        originalFormatContentType: mediaCache.OriginalFormatContentType,
                        originalFormatUrl: mediaCache.OriginalFormatUrl,
                        keepAspectRatio: keepAspectRatio,
                        resizeMode: resizeMode
                    };

                } else {
                    params = {
                        id: id,
                        //settings regarding the editor window
                        editorSettings: {
                            width: editorWidth,
                            height: editorHeight
                        },
                        //settings for communicating with core
                        coreSettings: {
                            client: ImageVault.ClientInstance,
                            mediaUrlBase: ImageVault.PropertyMediaCommon.mediaUrlBase
                        },
                        languageSettings: {
                            editorWidthInputLabel: ImageVault.PropertyMediaCommon.msg.editorWidthInputLabel,
                            editorHeightInputLabel: ImageVault.PropertyMediaCommon.msg.editorHeightInputLabel,
                            editorOkButtonText: ImageVault.PropertyMediaCommon.msg.editorOkButtonText,
                            editorCancelButtonText: ImageVault.PropertyMediaCommon.msg.editorCancelButtonText,
                            editorWarningIconText: ImageVault.PropertyMediaCommon.msg.editorWarningIconText,
                            editorReloadButtonText: ImageVault.PropertyMediaCommon.msg.editorReloadButtonText,
                            editorLoadErrorText: ImageVault.PropertyMediaCommon.msg.editorLoadErrorText,
                            title: ImageVault.PropertyMediaCommon.msg.title,
                        },
                        //current effects applied on the image
                        currentEffects: effectsString,
                        //end format (can be null)
                        targetFormat: {
                            width: propertyMediaOverlaySelectorInstance.width,
                            height: propertyMediaOverlaySelectorInstance.height,
                            resizeMode: propertyMediaOverlaySelectorInstance.resizeMode
                        },
                        //original image format
                        originalFormat: {
                            width: mediaCache.Original.Width,
                            height: mediaCache.Original.Height,
                            url: mediaCache.Original.Url,
                            contentType: mediaCache.OriginalFormatContentType
                        },
                        //return an array of effects that should be applied to the media
                        callback: function (eff) {

                            // if we have a value we will save it
                            if (eff) {
                                mediaReference.Effects = JSON.parse(eff);
                                propertyMediaOverlaySelectorInstance._setValue(mediaReference, propertyMediaOverlaySelectorInstance);
                            }

                            // reset editor
                            propertyMediaOverlaySelectorInstance.resetEditor(propertyMediaOverlaySelectorInstance);
                        },
                        originalFormatContentType: mediaCache.OriginalFormatContentType,
                        originalFormatUrl: mediaCache.OriginalFormatUrl,
                        keepAspectRatio: false,
                        nodeInfo: propertyMediaOverlaySelectorInstance.nodeCoords,
                        isInline: true
                    };
                }

                if (win.openEditorInstance) {
                    // Check if targetFormat is empty, then remove property value
                    if (params.targetFormat.height === 0 &&
                        params.targetFormat.width === 0 &&
                        params.targetFormat.resizeMode === 0)
                        params.targetFormat = null;

                    win.openEditorInstance(params);
                }
            };

            if (!ImageVault.PropertyMediaCommon.editorPopupMode && $.browser.msie) {
                var winSpec = 'width=' + (winSize.width) + ',height=' + (winSize.height) + ',resizable=yes';
                //Open window popup variant
                var win = window.open(url, name, winSpec);
                win.focus();
                $(win.document).ready(function () {

                    setTimeout(function () {
                        initEditorCallback(win);
                    },
                        1000);

                });

            } else {
                if (useInline) {
                    var $iframe = $(".ivNode iframe");

                    $iframe.attr("src", url);
                    $iframe.load(function () {
                        $iframe.unbind("load");
                        $iframe.unbind("keydown");
                        var win = $iframe.get(0).contentWindow;

                        initEditorCallback(win,
                            function () {
                                $(".ivNode").hide();
                            });
                    });
                } else {

                    $.fancybox({
                        type: "iframe",
                        href: url,
                        width: winSize.width,
                        height: winSize.height,
                        scrolling: 'no',
                        overlayColor: '#555',
                        overlayOpacity: 0.5,
                        showCloseButton: false,
                        onComplete: function () {
                            var $iframe = $('#fancybox-content iframe');
                            $iframe.load(function () {
                                $iframe.unbind("load");
                                $iframe.unbind("keydown");
                                var win = $iframe.get(0).contentWindow;
                                initEditorCallback(win, function () {
                                    $.fancybox.close();
                                });
                            });
                        },
                        onClosed: function () {
                            $.event.trigger("/imagevault/propertymediacommon/editorclosed");
                            return false;
                        }
                    });
                }

            }
        },

        //gets the media described by the given parameters
        //mediaReference, contains Id and Effects of the media to get
        //[optional] widh, heigth, resizeMode, describes the thumbnail settings that should be applied in addition to the effects in the reference
        //callback, is the function which takes a mediaItem as parameter.
        getMedia: function (mediaReference, contentType, width, height, resizeMode, callback) {
            //handle the optional parameters
            if (typeof contentType === "function") {
                callback = contentType;
                width = null;
            }
            var client = this.getClient();
            var parameters = {
                Filter: { Id: [mediaReference.Id] },
                Populate: { MediaFormats: [{ $type: "ImageVault.Common.Data.ThumbnailFormat,ImageVault.Common", Effects: [] }, { $type: "ImageVault.Common.Data.OriginalFormat,ImageVault.Common" }] },
                MediaUrlBase: ImageVault.PropertyMediaCommon.mediaUrlBase

            };
            //copy effects from mediaReference
            if (mediaReference.Effects && mediaReference.Effects.length > 0) {
                for (var i = 0; i < mediaReference.Effects.length; i++) {
                    parameters.Populate.MediaFormats[0].Effects.push(mediaReference.Effects[i]);
                }
            }
            //add thumb format (if supplied)
            if (width || height) {
                parameters.Populate.MediaFormats[0].Effects.push({ $type: "ImageVault.Common.Data.Effects.ResizeEffect,ImageVault.Common", Width: width, Height: height, ResizeMode: resizeMode || 0 });
            }
            //get the requested media
            client.json("MediaService/Find", parameters, function (m) {
                if (m === null || !m.length) {
                    callback(null);
                } else {
                    callback(m[0]);
                }
            });
        },
        //opens the ImageVault UI  
        //insertMultiple: true if we should be able to select multiple items.
        OpenImageVault: function (insertMultiple) {
            if (this.readOnly)
                return false;
            var self = this;
            var url = self.uri;

            url += "&formatId=" + self.thumbnailFormatId + "&insertMultiple=" + insertMultiple;
            url += "&EnsurePublishingSource=" + encodeURIComponent(ImageVault.PropertyMediaCommon.publishingIdentifier);
            url += "&MediaUrlBase=" + encodeURIComponent(ImageVault.PropertyMediaCommon.mediaUrlBase);

            url = ImageVault.Client.prototype._makeAbsoluteUrl(url);

            var name = self._getWindowName(self.hiddenFieldId);
            var wref = window.open(url, name, 'width=1034,height=768,resizable=yes,scrollbars');
            ImageVault.UiCallback.Instance.RegisterOpener(name, insertMultiple, function (data) { self.callback(data); });
            //Continous check of the window state...
            if (wref) {
                var intervalId = window.setInterval(function () {
                    if (!wref) {
                        window.clearInterval(intervalId);
                    }
                    else if (wref.closed) {
                        window.clearInterval(intervalId);
                        // Trig event IvWinClosed
                        $.event.trigger("/imagevault/propertymediacommon/ivwinclosed", self);
                    }
                }, 500);
            }
            // Trig event IvWinOpened
            $.event.trigger("/imagevault/propertymediacommon/ivwinopened", self);

            return false;
        },
        centerThumbnail: function ($elem, $mediaCache, $mediaList) {
            //height of thumbcontainer
            //in epi7, when changing to forms mode, the propertyMedia thumb container has no height. Default to 199 in that case.
            var parentHeight = $elem.parent().height() || 199;

            //height of default icon
            var elementHeight = 31;

            //when we want to center image in mediaitem not list, we pass through mediaCache to collect height.
            if ($mediaCache && $mediaCache.Thumb) {
                elementHeight = $mediaCache.Thumb.Height;
            }

            //if we want to center image in medialist we get height from image.
            if ($mediaList) {
                //elementHeight = $elem.height();
                elementHeight = $elem[0].height;
            }

            //if no height is set then we haven't loaded it yet. No idea to do anything...
            if (elementHeight > 0) {
                $elem.css('margin-top', (parentHeight - elementHeight) / 2).css('visibility', 'visible');
            }
        },
        htmlEncode: function (value) {
            var x = value.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
            return x;
        }
    };
    ns.PropertyMediaCommon = pmc;


})(jQuery, window.ImageVault != null ? window.ImageVault : window.ImageVault = {});
