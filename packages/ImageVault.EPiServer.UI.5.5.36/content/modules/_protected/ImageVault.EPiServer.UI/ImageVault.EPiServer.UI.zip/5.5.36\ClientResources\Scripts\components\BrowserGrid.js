﻿define([
    "dojo",
    "dojo/_base/lang",
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/string",
    "dojo/_base/Deferred",
    "dojo/on",

    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

    "dijit",
    "dijit/_WidgetBase",
    "dijit/layout/_LayoutWidget",

    "epi",

/* Cannot use epi-cms/dgrid/DnD anymore in 7.5 need to use the original DnD from dgrid */
	//"epi-cms/dgrid/DnD",
    "dgrid/extensions/DnD",
// "epi-cms/dgrid/formatters",
    "epi/dependency",
//imagevault
/*RefreshMixin only needed in EPiServer 7.1*/
//the _RefreshMixin adds a refresh event when dgrid has been refreshed.
     "imagevault/components/_RefreshMixin",
     "imagevault/_PropertyMediaMixin"
], function (
    dojo,
    lang,
    declare,
    aspect,
    domConstruct,
    stringUtil,
    Deferred,
    on,

    Keyboard,
    OnDemandGrid,
    Selection,

    dijit,
    _WidgetBase,
    _LayoutWidget,

    epi,

    DnD,
//  formatters,
    dependency,
	/*RefreshMixin only needed in EPiServer 7.1*/
    _RefreshMixin,
    _PropertyMediaMixin
) {

    return declare([_WidgetBase, _LayoutWidget, _PropertyMediaMixin], {

        // _gridClass: [private] Object
        //		The class to construct the grid with.
        /*RefreshMixin only needed in EPiServer 7.1*/
        _gridClass: declare([OnDemandGrid, _RefreshMixin, Selection, DnD, Keyboard]),

        // storeKeyName: [public] string
        //		The key of the store used to retrieve the store from the store registry.
        storeKeyName: null,

        // grid: [public] dgrid
        //		The grid that is used to display information.
        grid: null,

        // store: [public] dojo.store
        //		The store that contains the data.
        store: null,

        // dndTypes [public]
        //      The type used for drag/drop operations.
        dndTypes: ["ImageVaultMedia"],

        defaultGridMixin: null,
        // defaultGridMixin: [protected] object
        //		An object with default settings for dnd to mixin to the grid class.

        // deferred object used to signal when data is fetched
        _fetchDataDeferred: null,

        postMixInProperties: function () {
            // summary:
            //		Called after constructor parameters have been mixed-in; sets default values for parameters that have not been initialized.
            // tags:
            //		protected
            this.storeKeyName = "imagevault.browserstore";

            this.inherited(arguments);

            this.defaultGridMixin = {
                selectionMode: "single",
                //mousedown event added in dgrid component from 7.5
                //needed for single click and drag function.
                selectionEvents: "click,mousedown,dgrid-cellfocusin",
                dndParams: {
                    creator: lang.hitch(this, this._dndNodeCreator),
                    copyOnly: true,
                    selfAccept: false
                }
            };

            if (!this.store && this.storeKeyName) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get(this.storeKeyName);
                this.store.idProperty = "Id";
            }
        },
        startup: function () {
            // summary:
            //		Connects event handlers to common grid events.
            // tags:
            //		protected

            this.inherited(arguments);

            //override the grid.refresh and _processScroll method for checking access rights.            
            var grid = this.grid;
            var self = this;
            var orgRefresh = grid.refresh;
            grid.refresh = function () {
                on.emit(grid.domNode, "loadingStarted", { bubbles: true, cancelable: true });

                //make sure we are logged into IV UI before refreshing the grid
                self.checkLoginStatus().then(function () {
                    orgRefresh.apply(grid, arguments);
                }, function (message) {
                    self._showErrorMessage(message);
                    on.emit(grid.domNode, "error", { message: message, bubbles: true, cancelable: true });
                });
            };
            var orgProcessScroll = grid._processScroll;
            grid._processScroll = function () {

                //this event goes haywire when scrolling in the grid. It gets fired all the time so we better find 
                //a more suitable place to emit the event if we want to support visual feedback on partial loading
                //on.emit(grid.domNode, "loadingStarted", { bubbles: true, cancelable: true });

                //make sure we are logged into IV UI before refreshing the grid
                self.checkLoginStatus().then(function () {
                    orgProcessScroll.apply(grid, arguments);
                }, function (message) {
                    self._showErrorMessage(message);
                    on.emit(grid.domNode, "error", { message: message, bubbles: true, cancelable: true });
                });
            };
            grid.on("dgrid-select", dojo.hitch(this, this._onSelect));

            //when grid has been refreshed, notify the _fetchDataDeferred about the progress
            var refreshFunction = function () {
                if (this._fetchDataDeferred) {
                    this._fetchDataDeferred.resolve();
                    this._fetchDataDeferred = null;
                }
                on.emit(grid.domNode, "loadingCompleted", { bubbles: true, cancelable: true });
            };
            /*dgrid-refresh-complete event added in 7.5*/
            this.grid.on("dgrid-refresh-complete", lang.hitch(this, refreshFunction));
            /*Refresh added by RefreshMixin, only needed in 7.1*/
            this.grid.on("refresh", lang.hitch(this, refreshFunction));
            grid.on("dgrid-error", lang.hitch(this, function (e) {
                var message = "Error loading data. Check connectivity to store";
                var data = e && e.error && e.error.response ? e.error.response.data : null;
                if (data) {
                    try {
                        data = JSON.parse(data);
                        if (data && data.isException)
                            message = data.message;
                    } catch (e) { }
                }
                self._showErrorMessage(message);
                on.emit(grid.domNode, "error", { message: message });
            }));

            function fileExists(fileUrl) {
                try {
                    var http = new XMLHttpRequest();
                    http.open("HEAD", fileUrl, false);
                    http.send();

                    return http.status !== 404;
                } catch (ex) {
                    return false;
                }
            }

            // Add custom style for symbols if custom css file exists
            if (fileExists("/Content/imagevault.css")) {
                var link = document.createElement("link");
                link.href = "/Content/imagevault.css";
                link.type = "text/css";
                link.rel = "stylesheet";
                link.media = "screen,print";

                document.getElementsByTagName("head")[0].appendChild(link);
            }
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            var gridSettings = lang.mixin({
                columns: {
                    name: {
                        //Sample of how to apply custom renderer
                        renderCell: lang.hitch(this, this._renderItem)
                    }
                },
                //default size displays 4 items in a row so make sure that the value is divideable by 4
                minRowsPerPage: 40,
                //since the range isn't finite we get strange results on the top of the grid
                //if we allow removal of farOffItems (atleast from the beginning of the grid)
                farOffRemoval: Infinity,
                store: this.store,
                dndSourceType: this.dndTypes
            }, this.defaultGridMixin);

            this.grid = new this._gridClass(gridSettings, this.domNode);
            this.grid.renderRow = this._renderRow;
            this.grid.set("showHeader", false);

            dojo.subscribe("/dnd/drop", lang.hitch(this, function (source, nodes, copy, target) {
                //only listen to your own events
                if (source.grid === this.grid) {
                    this.grid.deselect(nodes[0]);
                }
            }));
        },

        _renderRow: function (item, options) {

            var isVideo = item.OriginalItem &&
                item.OriginalItem.ContentType &&
                item.OriginalItem.ContentType.toLowerCase().substring(0, "video/".length) === "video/";

            // create div that contains image
            var thumbNailContainer = dojo.create("div");

            // Wrapper for symbols on media
            var symbolsWrapper = document.createElement("div");

            // Set classname on symbols wrapper
            symbolsWrapper.className = "media-library-symbols";

            // Append symbols placeholder
            thumbNailContainer.appendChild(symbolsWrapper);

            // Function that creates symbol
            function createSymbol(names, values, cssClass, symbolsWrapper) {

                // Container for symbol
                var symbolHtml = document.createElement("span");

                // Symbol html string
                var symbolString = "<div class=\"media-library-symbol media-library-symbol-" +
				cssClass + "\">\
                    <span class=\"media-library-symbol-icon\"><div class=\"media-library-symbol-description\">";
                if (names != null) {
                    // Loop throught every name
                    for (var i = 0; i < names.length; i++) {
                        var name = names[i];
                        var value = values[i];

                        // Try parse value as date
                        if (value.indexOf("/Date(") != -1) {
                            value = value.replace("/Date(", "").replace(")/", "");
                            var date = new Date(parseInt(value));
                            value = date.getFullYear() + "-" + (date.getMonth() < 10 ? 0 : "") + (date.getMonth() + 1) + "-" + ((date.getDate() + 1) < 10 ? 0 : "") + date.getDate();
                        }

                        // Name and description for symbol (metadata definition name and metadata value)
                        if (name != null || value != null) {
                            symbolString +=
                            "<strong>" + name + "</strong><p>" + value + "</p></br>";
                        }
                    }
                }
                symbolString += "</div></span></div>";

                symbolHtml.innerHTML = symbolString;

                symbolsWrapper.appendChild(symbolHtml);
            };

            // Video icon
            if (isVideo) {
                createSymbol(null, null, "video-media", symbolsWrapper);
            }

            // Shared icon
            if (item.Shared) {
                createSymbol(null, null, "shared-media", symbolsWrapper);
            }

            var groupedSymbolMetadata = [];

            // Custom icons
            for (var i = 0; i < item.Metadata.length; i++) {

                var metadata = item.Metadata[i];
                // Check if show as symbol is set on metadata definition
                if (metadata.SymbolKey !== null && metadata.Value != null && metadata.Value !== false) {
                    if (groupedSymbolMetadata[metadata.SymbolKey] === undefined) {
                        groupedSymbolMetadata[metadata.SymbolKey] = [];
                        groupedSymbolMetadata[metadata.SymbolKey].push(metadata);
                    } else {
                        groupedSymbolMetadata[metadata.SymbolKey].push(metadata);
                    }
                }
            }


            var groupedSymbolMetadataLength = Object.keys(groupedSymbolMetadata).length;

            if (groupedSymbolMetadataLength != undefined) {

                // Custom icons
                for (var key in groupedSymbolMetadata) {
                    var metadataGroup = groupedSymbolMetadata[key];

                    var names = [];
                    var values = [];

                    for (var j = 0; j < metadataGroup.length; j++) {
                        names.push(metadataGroup[j].Name);
                        values.push(metadataGroup[j].Value);
                    }

                    createSymbol(names, values, metadataGroup[0].SymbolKey, symbolsWrapper);

                }
            }


            // Create the div and place it inside thumbNailContainer
            dojo.create("img", { width: "70", height: "70", src: item.Thumbnail.Url }, thumbNailContainer);

            return thumbNailContainer;
        },

        fetchData: function (queryParameters) {
            //  summary:
            //      Fetches the data to the grid and updates it according to the queryParameters.
            //  queryParameters:
            //      The parameters to send to the store
            //  returns:
            //      A Deferred object to be invoked when fetching is completed.

            var oldFetchDataDeferred = this._fetchDataDeferred;
            this._fetchDataDeferred = new Deferred();

            //if more listeners are listening, make sure that we queue them up
            if (oldFetchDataDeferred) {
                this._fetchDataDeferred.then(function (value) {
                    oldFetchDataDeferred.resolve(value);
                });
            }

            this.grid.set("queryOptions", { ignore: ["query"], sort: [{ attribute: "Name", descending: true }] });
            this.grid.set("query", queryParameters);

            return this._fetchDataDeferred;
        },

        _onSelect: function (e) {
            // summary:
            //		Publish a context request when a version is selected in the list.
            // tags:
            //		private

            //Do something here..
        },

        restore: function () {
            // summary: Restore component visuals
            this.resize();
        },

        _showErrorMessage: function (errorMessage) {
            this.grid.cleanup();

            // There is no public method for setting messages, so use the same style as dgrid.
            this.grid.contentNode.innerHTML = "<div class='errorMessage'>" +
                "<p class='heading'>Error</p>" +
                "<p class='message'>[" + errorMessage + "]</p>" +
                "</div>";
        },

        _dndNodeCreator: function (item, hint) {
            // summary:
            // Custom DnD avatar creator method

            var template = "<div><img src=\"${imageUrl}\" alt=\"${alt}\"/></div>";
            var node = domConstruct.toDom(stringUtil.substitute(template, {
                alt: item.Name || "ImageVault media",
                imageUrl: item.Thumbnail.Url
            }));

            return {
                "node": node,
                "type": this.dndTypes,
                "data": item,
                //HACK, we replaced episervers Avatar class and by supplying this property we signal it to do standard dojo Avatar handling instead.
                supressEPiAvatarCreation: true
            };
        }
    });
});