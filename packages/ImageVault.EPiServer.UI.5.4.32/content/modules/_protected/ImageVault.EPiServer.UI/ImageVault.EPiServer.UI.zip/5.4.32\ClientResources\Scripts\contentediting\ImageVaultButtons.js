﻿define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "epi",
    "epi/shell/_StatefulGetterSetterMixin",
    "epi-cms/contentediting/command/BlockRemove"
],

function (declare, lang, Stateful, epi, _StatefulGetterSetterMixin, RemoveCommand) {

    return declare([Stateful, _StatefulGetterSetterMixin], {
        // summary:
        //      Exposes all available block editing commands

        model: null,

        remove: null,

        constructor: function (settings) {
            lang.mixin(this, settings);

            // Create the command
            this.remove = this.remove || new RemoveCommand();
        },

        _setModelAttr: function (model) {
            this._set("model", model);

            // Update the model on the commands
            this.remove.set("model", model);
        }
    });
});
